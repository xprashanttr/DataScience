WHENEVER sqlerror exit 1
WHENEVER oserror exit 1

DECLARE
-- v_date   DATE := TRUNC (idate);
   v_date   DATE := TRUNC (TO_DATE (SUBSTR (TRIM ('&1'), -6, 6), 'YYMMDD'));
BEGIN
   DELETE FROM grp_campaign_data
         WHERE local_date = v_date AND ds_id = 3;

   INSERT INTO grp_campaign_data
               (local_date, ds_id, pub_id, cam_id, rep_demo_id, uniq_users,
                impressions)
      SELECT   x.local_date, x.ds_id, x.pub_id, x.cam_id, dg.rep_demo_id,
               SUM (weight) audience, SUM (weight * impression) impression
          FROM (SELECT   v_date local_date, c.cam_start_date, 3 ds_id,
                         p.pub_id, p.cam_id, meter_id, member_id,
                         SUM (impression) impression
                    FROM grp_campaign c JOIN grp_panel_data p
                         ON p.cam_id = c.cam_id
                   WHERE v_date BETWEEN c.cam_start_date AND c.cam_end_date
                     AND p.local_date <= v_date
                GROUP BY c.cam_start_date,
                         p.pub_id,
                         p.cam_id,
                         meter_id,
                         member_id) x
               JOIN
               grp_panel_weight w
               ON w.local_date = x.cam_start_date
             AND w.panel_site_id = x.meter_id
             AND w.member_id = x.member_id
               JOIN grp_report_demo_group dg
               ON dg.gen_id = w.gen_id AND dg.age_grp_id = w.age_grp_id
      GROUP BY x.local_date, x.ds_id, x.pub_id, x.cam_id, dg.rep_demo_id
        HAVING SUM (weight) > 0;

-- added on 20-dec-2010 : campaign level aggregated data: pub_id = 1
   INSERT INTO grp_campaign_data
               (local_date, ds_id, pub_id, cam_id, rep_demo_id, uniq_users,
                impressions)
      SELECT   local_date, 3 ds_id, 1 pub_id, cam_id, rep_demo_id,
               SUM (uniq_users), SUM (impressions)
          FROM grp_campaign_data
         WHERE local_date = v_date AND ds_id = 3
      GROUP BY local_date, ds_id, cam_id, rep_demo_id;

   COMMIT;

   DELETE FROM grp_campaign_total
         WHERE local_date = v_date AND ds_id = 3;

   INSERT INTO grp_campaign_total
               (local_date, ds_id, pub_id, cam_id, audience, impression)
      SELECT   local_date, 3 ds_id, pub_id, cam_id, SUM (uniq_users) audience,
               SUM (impressions) impression
          FROM grp_campaign_data
         WHERE ds_id = 3 AND local_date = v_date
      GROUP BY local_date, pub_id, cam_id;

   COMMIT;
END;
/

