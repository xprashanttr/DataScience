#!/bin/bash
grphome=`dirname $0`
. $HOME/.profile
. $HOME/prashant/GRP/.ftp_vars 
cd $grphome

# $1 : file_src :: fb or sc etc
# $2 : sftp server
# $3 : sftp remote folder
# $4 : logfile : grp.sh.log
# $5 : weblogfile : weblog

############################

filestem=$1
sftp_server=$2
sftp_folder=$3
logfile=$4
weblogfile=$5

#echo "`date '+%Y-%m-%d %H.%M.%S'` :FTP for $filestem files at $sftp_server/$sftp_folder starts" | tee -a $logfile $weblogfile

ssh $sftp_server << EOF_SSH
cd $sftp_folder

	ftp -n $FTP_HOST << EOF_FTP
	user $FTP_USER $FTP_PASSWORD
	cd $FTP_DATA_FOLDER
	prompt
	binary
	mget $filestem*
	quit
EOF_FTP

EOF_SSH

#echo "`date '+%Y-%m-%d %H.%M.%S'` :FTP for $filestem files at $sftp_server/$sftp_folder ends" | tee -a $logfile $weblogfile

