
COL c_time noprint v_time 
SELECT '&1' c_time FROM DUAL;

<%

_run.emailTo='Seema.Varma@Nielsen.com;Larry.Hammond@Nielsen.com;Clay.Campbell.Consultant@nielsen.com;Jonathan.Rummel@Nielsen.com;Larry.Hammond@Nielsen.com;Jagdish.Patil@Nielsen.com;Ankur.Tandon.ap@Nielsen.com;Prashant.Tripathi.ap@Nielsen.com'
_run.emailSubject = 'NOCR Daily campaign report ' + _run.v_time

%>;


DEFINE message=_array
DEFINE message= Daily campaign report

COL _rowset noprint message 
SELECT   a.local_date, d.ds_name datasource, a.cam_id,
         COALESCE (cam_name, cam_tag, encry_cam_tag) campaign,
         COALESCE (pub_name, pub_tag, encry_pub_tag) site, audience,
         impression
    FROM grp_campaign_total a JOIN grp_campaign b ON (a.cam_id = b.cam_id)
         JOIN grp_publisher c ON (a.pub_id = c.pub_id)
         JOIN grp_data_source d ON (a.ds_id = d.ds_id)
   WHERE local_date >= TRUNC (SYSDATE) - 5
ORDER BY cam_id,
         local_date desc,
         ds_name,
         COALESCE (pub_name, pub_tag, encry_pub_tag) DESC;


email message;
