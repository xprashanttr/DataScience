DECLARE
   datasource varchar2(64) :='&1';
   exttbl    VARCHAR2 (128) := 'EXT_GRP_'||datasource;
   v_table   VARCHAR2 (128);
BEGIN
   SELECT table_name
     INTO v_table
     FROM user_tables
    WHERE table_name = UPPER (exttbl);
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      EXECUTE IMMEDIATE 'CREATE TABLE '||exttbl||'
    (
    local_date                    VARCHAR2(10),
    cam_tag                  	VARCHAR2(50),
    cr_tag				VARCHAR2(50),
    pub_tag				VARCHAR2(150),
    age				NUMBER(3,0),
    gender                        NUMBER(1,0),
    uniq_users                    NUMBER(15,0),
    impressions                   NUMBER(15,0),
    frequency                     NUMBER
    )
  ORGANIZATION EXTERNAL (
   DEFAULT DIRECTORY  EXT_GRP_DIR
    ACCESS PARAMETERS(RECORDS delimited BY newline CHARACTERSET UTF8
           badfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.bad''
           logfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.log''
           fields terminated BY "|"
           OPTIONALLY ENCLOSED BY ''"''
           MISSING FIELD VALUES ARE NULL
           REJECT ROWS WITH ALL NULL FIELDS
 )
   LOCATION (
    EXT_GRP_DIR:'''||datasource||'.dat''
   )
  ) REJECT LIMIT 0 ';
END;
/


-- script to check data quality
--@facebook_datacheck.sql
--@email_fb_datacheck.sql
!sqlsh -u scratch@adrcoll -s d -j pra_test -c def -o /adr/core/cfg.ora/phoenix.cfg @"/adr/prashant/GRP/email_fb_datacheck.sql &2"


-- columns change on 19nov2010: new file format
INSERT INTO grp_publisher
            (/*pub_tag*/ encry_pub_tag)
   SELECT DISTINCT /*pub_tag*/ pub_tag
              FROM ext_grp_facebook
   MINUS
   SELECT /*pub_tag*/ encry_pub_tag
     FROM grp_publisher
;

-- cam_tag should be NULLABLE now <DDL CHANGE>
INSERT INTO grp_campaign
            (/*cam_tag,*/ cam_start_date,itime,encry_cam_tag)
   SELECT   /*cam_tag,*/ MIN (to_date(local_date,'YYYY-MM-DD')) cam_start_date,sysdate,cam_tag
       FROM ext_grp_facebook a
      WHERE NOT EXISTS (SELECT 1
                          FROM grp_campaign
                         WHERE encry_cam_tag = a.cam_tag)
   GROUP BY cam_tag
;

/*
DELETE FROM grp_facebook_import
      WHERE local_date IN (SELECT DISTINCT TO_DATE (local_date, 'YYYY-MM-DD')
                                      FROM ext_grp_facebook);
*/

DELETE FROM grp_facebook_import a
      WHERE EXISTS (SELECT 1 FROM 
                    (SELECT DISTINCT TO_DATE (local_date, 'YYYY-MM-DD') local_date, cam_id
                                  FROM ext_grp_facebook b JOIN grp_campaign c
                                       ON (b.cam_tag = c.encry_cam_tag)) x
                WHERE x.local_date = a.local_date AND x.cam_id = a.cam_id);


INSERT INTO grp_facebook_import
            (local_date, cam_id, age, gender, uniq_users, impressions,
             frequency, pub_id, cr_tag)
   SELECT TO_DATE (local_date, 'YYYY-MM-DD'), cam_id, age, gender, uniq_users,
          impressions, frequency, pub_id, cr_tag
     FROM ext_grp_facebook a JOIN grp_campaign b
          ON b.encry_cam_tag = a.cam_tag
          JOIN grp_publisher s ON s.encry_pub_tag = a.pub_tag
          ;

COMMIT;

-- aggregation of data 
BEGIN
   FOR idate IN (SELECT DISTINCT local_date
                            FROM ext_grp_facebook order by local_date)
   LOOP
      xgrp.prepare_facebook (TO_DATE (idate.local_date, 'YYYY-MM-DD'));
   END LOOP;
END;
/

