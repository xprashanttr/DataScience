#!/bin/bash

############################################################################
# WRAPPER SCRIPT TO RUN AdR 2.0 COLLECTION AND CLASSIFICATION JOBS
# VERSION 1.1
# CREATED DATE: 18-FEB-2010
# CREATED BY SHISHIR SATHE (SATHSH01)
#############################################################################


cd `dirname $0`
name=`basename $0`
basedir=`pwd`

. ~adrusr/.profile
. .email_list
. $basedir/adr_include.sh
logfile="$ADRLOGFOLDER/$1_$2_$name.log"
export TNS_ADMIN=./

mypid=$$

if test -z "$run_cmjobname"
then
job_name=$name
else
job_name=$run_cmjobname
fi


start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"
echo $start_msg >> $logfile

function log {
echo "`date '+%Y-%m-%d %H.%M.%S'`: $1: $name: $2" >> $logfile

if test $1 -le 3
then
sed "1,/$start_msg/d" $logfile | mail -s "ERROR: $job_name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}

function get_pw {
cat .pw |tr [:lower:] [:upper:] |awk '{if ($1==dbusr && $3==dbname) print $2}' dbusr="`echo $1 | tr [:lower:] [:upper:]`" dbname="`echo $2 | tr [:lower:] [:upper:]`"
}

log 5 "start $0 $*"


case $2 in
'stgcol') dbname="stgcoll"
       ;;
'adrcol') dbname="adrcoll"
      ;;
*) log 3 "ERROR:unknown environment"
     ;;
esac

case $1 in
'scratch')dbusr="scratch"
    ;;
*) log 3 "ERROR:unknown dbuser"
     ;;
esac

for thisdbusr in $dbusr
do
dbpasswd="`get_pw $thisdbusr $dbname`"
#echo "$dbpasswd"

if test -z "$dbpasswd"
then
log 3  "ERROR:passwd not known for $thisdbusr@$dbname contact database administrator"
fi


log 5 "connecting to db $thisdbusr@$dbname"
sqlplus -S /NOLOG << eof++ >> $logfile
connect $thisdbusr/$dbpasswd@$dbname
$3
exit;
eof++
exit_status=$?
if test $exit_status  -ne 0
then
log 3 "ERROR:Oracle error"
else
##check for Oracle Error string in logfile
if test -n "`sed "1,/$start_msg/d" $logfile | egrep "^ORA-|^SP2-|^ERROR"`"
then
log 3 "ERROR:error string found in $logfile"
fi
fi

done

log 5 "done $0 $*"

