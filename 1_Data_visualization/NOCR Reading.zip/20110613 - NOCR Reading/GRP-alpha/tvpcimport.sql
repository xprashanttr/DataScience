whenever sqlerror exit 1
whenever oserror exit 1

--exec xgrp.prepare_tvpc_v3(to_date(substr(trim('&1'),-6,6),'YYMMDD'));

/*
BEGIN
   raise_application_error (-20001, 'Do not Run this script');
END;
/
*/

--======================================================================
/*
Below part added to bring below steps in flow
!! pull panel data
!! populate "grp_panel_npm" table
!! process weight files
!! aggregation of panel data to populate grp_campaign_data and grp_campaign_total tables

-- second part is executed in the shell script
-- refer "populate_panel_data" job in grp.sh
-- refer "tvpcpopulate.sql" for third part
*/

--======================================================================

--(1) first part :: get new meter ids and populate grp_panel_nmp table
DECLARE
-- v_date   DATE := TRUNC (idate);
   v_date   DATE := TRUNC (to_date(substr(trim('&1'),-6,6),'YYMMDD'));
BEGIN

  		-- get tvpc panel instance level tracked campaign exposure data
		DELETE FROM grp_tvpc_instance WHERE local_time >= v_date and local_time < v_date+1 ;
		
		INSERT INTO grp_tvpc_instance
		SELECT i.sc_url_instance_id,i.meter_id,i.computer_id,i.local_time,i.url_name,i.site_source,
		       i.pcses_id,i.domain_name,i.tag_client_id,s.member_id,s.surf_location_id,s.start_time,
		       s.end_time,i.DURATION,i.is_complete,
		       SUBSTR(url_name,INSTR(url_name,'&ca=') +4,INSTR(url_name,'&',INSTR(url_name,'&ca=') +2) - INSTR(url_name,'&ca=') -4) campaign,
		       SUBSTR(url_name,INSTR(url_name,'&pc=') +4,INSTR(url_name,'&',INSTR(url_name,'&pc=') +2) - INSTR(url_name,'&pc=') -4) publisher
		FROM /*nspl_201.cl1_sc_url_instance@to_loadus*/ phx_201.cl1_sc_url_instance@to_rptus i
		     JOIN /*nspl_201.cl1_pc_session@to_loadus*/ phx_201.cl1_pc_session@to_rptus s
          ON s.meter_id = i.meter_id AND s.pcses_id = i.pcses_id
		WHERE i.local_time >= v_date
		AND   i.local_time <  v_date+1
		AND   i.tag_client_id in ('ade-ca','nocr-ca')
		AND   INSTR(url_name,'&ca=') > 0
		AND   INSTR(url_name,'&pc=') > 0;
		
		COMMIT;
				
		INSERT INTO grp_panel_info
		( panel_site_id, member_id, dob,gen_id )
		SELECT panel_site_id,
		       member_id,
		       dob,
		       gender_id
		FROM def_phx.idv_member_info@to_rptus
		WHERE (panel_site_id,member_id) IN 
        (SELECT DISTINCT i.meter_id, i.member_id
            FROM grp_tvpc_instance i 
       LEFT JOIN grp_panel_info p ON p.panel_site_id = i.meter_id AND p.member_id = i.member_id
		  WHERE i.local_time >= v_date 
            AND i.local_time < v_date+1
            AND p.panel_site_id IS NULL);

  	   COMMIT;
		                                    
		DELETE FROM grp_panel_data WHERE local_date=v_date;

		INSERT INTO grp_panel_data
		 (local_date, computer_id, meter_id, member_id, surf_location_id,
		 cam_id, pub_id, impression)
		SELECT TRUNC(b.local_time) local_date,computer_id,meter_id,
		       member_id,surf_location_id,cam_id,pub_id,
		       COUNT(1) impression
		FROM grp_campaign a
		     JOIN grp_tvpc_instance b ON b.campaign = a.cam_tag
		     JOIN grp_publisher p ON p.pub_tag = b.publisher
		WHERE b.local_time >= v_date
		AND   b.local_time < v_date+1
		AND   b.local_time BETWEEN a.cam_start_date
		AND   a.cam_end_date
		GROUP BY TRUNC(b.local_time),computer_id,meter_id,
		         member_id,surf_location_id,cam_id,pub_id;
	   COMMIT;


----------------------------
-- populating GRP_PANEL_NPM
-- This table sis used in weight population(populate_grp_panel_weight procedure)
   BEGIN
      EXECUTE IMMEDIATE 'DROP TABLE grp_panel_npm_tmp';
   EXCEPTION
      WHEN OTHERS
      THEN
         IF (SQLCODE = -942)     --if ORA-00942: table or view does not exist
         THEN
            NULL;
         ELSE
            RAISE;
         END IF;
   END;

   EXECUTE IMMEDIATE    'CREATE TABLE grp_panel_npm_tmp UNRECOVERABLE AS
		SELECT --+driving_site(a) index(a,UIX_DAT_PS_INFO_02)
		       a.meter_id,
		       SUBSTR(login_id,1,7) folder_id,
		       a.panel_site_id
		FROM mgus_i2.dat_ps_info@to_nnm1 a
		     JOIN mgus_i2.dat_ps_login_info@to_nnm1 b ON b.panel_site_id = a.panel_site_id
		WHERE a.meter_id IN (SELECT DISTINCT p.meter_id
		                     FROM grp_panel_data p
		                          LEFT JOIN grp_panel_npm n ON n.meter_id = p.meter_id
		                     WHERE p.local_date = '''
                     || v_date
                     || ''' AND n.meter_id IS NULL)';

   EXECUTE IMMEDIATE 'INSERT INTO grp_panel_npm
		            (meter_id, folder_id, panel_site_id)
		   SELECT meter_id, folder_id, panel_site_id
		     FROM grp_panel_npm_tmp';

   COMMIT;
END;
/


/*
--(2) second part :: Process weight file for v_date
-- revisit filename generating part: check century and year part in new files
COL c_fname  print new_val v_fname
SELECT 'NATN.PR.D492.WEIGHT.CPP.A21.S00.D110'||to_char(TRUNC(SYSDATE),'DDD') c_fname
  FROM DUAL;

SELECT 'NATN.PR.D492.WEIGHT.CPP.A21.S00.D110'||to_char(TRUNC (to_date(substr(trim('&1'),-6,6),'YYMMDD')),'DDD') c_fname
  FROM DUAL;
*/

