


prompt Starting : ${new Date()} ${_iargs} ${System.getProperty("sqlsh.pid")}
SET termout      OFF

define run_date=${_options.d ? _options.d : new java.text.SimpleDateFormat("yyMMdd").format(new java.util.Date())}
DEFINE v_include_universe_id=1

/*
 All parameters passed via shell environment 
*/

prompt Starting : ${new Date()} ${_iargs} ${System.getProperty("sqlsh.pid")}
SET termout      OFF

define run_date=${_options.d ? _options.d : new java.text.SimpleDateFormat("yyMMdd").format(new java.util.Date())}

--Below line commented - Suren
--define run_sample=${_options.s instanceof java.lang.Boolean ? 1 : _options.s}
define run_basedir=${_execs.userPath}
define run_country=${_options.c}
define run_tnsname=${_options.u}
define v_run_schema=ADR_&run_country
define v_platform=&run_country
define v_status_dir=&run_basedir.status/
define v_dynamic_sql_dir=&run_basedir/dynamic_sql/

--Below line commented - Suren
--DEFINE v_period_type=<%= (System.getenv("run_period") ? System.getenv("run_period").toLowerCase() : 'm') %>;

define v_period_type_char=${_options.s.toUpperCase()}

/*
SET termout      OFF
SET serveroutput OFF
SET timing       OFF
SET verify       OFF
SET echo         OFF
*/

DEFINE backslash_char=\
DEFINE dollar_char=$
DEFINE ampersand_char=&

DEFINE v_adr_def=ADR_DEF
DEFINE v_stats_schema=DEF
DEFINE v_adr_schema=ADR_&run_country
DEFINE v_adr_fe_schema=ADR_FE_&run_country
DEFINE v_msqa_schema = 'msqa'
DEFINE v_pqa_schema = 'QA_PROD'
DEFINE v_postfix= monthly
DEFINE v_postfix_short= MON
DEFINE v_suffix=MONYY
--Added for numeric change - Bhasker
DEFINE relaxed_cast='NUMERIC(38,8)'
DEFINE v_load_path='/internet/apps/adr/core' --added by suren
DEFINE v_load_log_path='/internet/apps/adr/core/log'     --added by suren

ALTER SESSION SET nls_date_format='DD-MON-YYYY';
ALTER SESSION SET skip_unusable_indexes = TRUE;
ALTER SESSION ENABLE PARALLEL DML;
ALTER SESSION SET CURSOR_SHARING = EXACT;


COL c_oracle_period print new_val v_oracle_period
SELECT (CASE UPPER('&v_period_type_char')
           WHEN 'D' THEN TO_DATE('&run_date','YYMMDD') - TO_DATE(2451182, 'J')
           WHEN 'W' THEN TRUNC(((TO_DATE('&run_date','YYMMDD') - TO_DATE (2451176, 'J')) / 7))
           WHEN 'M' THEN TRUNC(MONTHS_BETWEEN (TO_DATE('&run_date','YYMMDD'), TO_DATE (2451180, 'J')))
           WHEN 'Q' THEN TRUNC(((MONTHS_BETWEEN (TO_DATE('&run_date','YYMMDD'), TO_DATE (2451180, 'J')) / 3))) + 1
           WHEN 'Y' THEN TRUNC(((MONTHS_BETWEEN (TO_DATE('&run_date','YYMMDD'), TO_DATE (2451180, 'J')) / 12 ))) + 1
        END
       ) c_oracle_period
  FROM DUAL;


COL c_ora_period_type print new_value v_ora_period_type
SELECT DECODE('&v_period_type_char','D',4,'W',3,'M',2,'Q',1,'Y',0) c_ora_period_type FROM DUAL;

COL c_local_time      noprint new_val v_local_time
COL c_period_type     noprint new_val v_period_type
COL c_tpartition      noprint new_val v_tpartition
COL c_tpart_time      noprint new_val v_tpart_time
COL c_next_period     noprint new_val v_next_period
COL c_timestamp       noprint new_val v_timestamp
COL c_remote_db       noprint new_val v_remote_db
COL c_mail_host       noprint new_val run_mail_host

SELECT TO_CHAR (TO_DATE ('&run_date', 'YYMMDD'), 'DD-MON-YYYY') c_local_time,
       run_period c_period_type,
       RTRIM (LTRIM (run_period || TO_CHAR (run_date, 'YYYYMMDD'))
             ) c_tpartition,
       TO_CHAR (ADD_MONTHS (run_date, 1), 'DD-MON-YYYY') c_tpart_time,
       DECODE (UPPER (run_period),
               'M', TO_CHAR (ADD_MONTHS (run_date, 1)),
               'W', TO_CHAR (NEXT_DAY (run_date, 'MONDAY')),
               'Q', TO_CHAR (ADD_MONTHS (run_date, 3))
              ) c_next_period,
       TO_CHAR (SYSDATE, 'DD_HH24MISS') c_timestamp,
       DECODE (RTRIM (LTRIM (UPPER ('&run_country'))),
               'US', 'ntsparodb02.paris.netratings.com',
               'SC', 'ntsparodb02.paris.netratings.com',
               'JP', 'admin-5.prod.netratings.com',
               DECODE (RTRIM (LTRIM (UPPER ('&run_tnsname'))),
                       'PHXWFE', 'ntsparodb02.paris.netratings.com',
                       '192.168.1.69'
                      )
              ) c_mail_host,
       DECODE (RTRIM (LTRIM (UPPER ('&run_tnsname'))),
               'NNC2', '@rptemea.world ',
               'NNC3', '@rptemea.world ',
               'NRTC', '@rptemea.world ',
               'PHXWFE', '@to_reporting_db ',
               'NNO5', '@to_reporting_db ',
               'LOADEMEA', '@to_reporting_db ',
               'LOADUS', '@to_reporting_db ',
               'JLOAD', '@to_reporting_db ',
               'DAV', DECODE (UPPER ('&run_country'),
                              'US', '@to_rptus ',
                              '@to_rptemea '
                             ),
               'TOOLS', DECODE (UPPER ('&run_country'),
                                'US', '@to_rptus ',
                                'JP', '@to_rptjp ',
                                '@to_rptemea '
                               ),
               'NSTOOLS', DECODE (UPPER ('&run_country'),
                                  'US', '@to_rptus ',
                                  '@to_rptemea '
                                 )
              ) c_remote_db
  FROM (SELECT DECODE
                  (NVL (UPPER (RTRIM ('&run_period')), 'M'),
                   'M', ADD_MONTHS
                                  (TRUNC (NVL (TO_DATE (RTRIM ('&run_date'),
                                                        'YYMMDD'
                                                       ),
                                               SYSDATE
                                              ),
                                          'MON'
                                         ),
                                   -1
                                  ),
                   'W', NEXT_DAY (NVL (TO_DATE (RTRIM ('&run_date'), 'YYMMDD'),
                                       SYSDATE
                                      ),
                                  'MONDAY'
                                 )
                    - 14,
                   'D', NVL (TO_DATE (RTRIM ('&run_date'), 'YYMMDD'), SYSDATE),
                   'Q', ADD_MONTHS
                                  (TRUNC (NVL (TO_DATE (RTRIM ('&run_date'),
                                                        'YYMMDD'
                                                       ),
                                               SYSDATE
                                              ),
                                          'MON'
                                         ),
                                   -3
                                  )
                  ) run_date,
               NVL (UPPER (RTRIM ('&run_period')), 'M') run_period
          FROM DUAL) ;


<%
_run.put("ReportCalendar",Calendar.getInstance());
_run.get("ReportCalendar").setTime((new java.text.SimpleDateFormat("dd-MMM-yyyy")).parse(_run.v_local_time));

_run.calendar = {i,fmt -> 
        Calendar nc = _run.get("ReportCalendar").clone();
        nc.add(Calendar.MONTH, i);
        return new java.text.SimpleDateFormat(fmt == null ? "yyyyMMdd" : fmt).format(nc.getTime());
        };

_run.calendarDate = {dt,i,fmt -> 
        Calendar c = Calendar.getInstance();
        def f = new java.text.SimpleDateFormat(fmt == null ? "yyyyMMdd" : fmt);
        c.setTime(f.parse(dt));
        c.add(Calendar.MONTH, i);
        return f.format(c.getTime());
        };

_run.println = {txt, ou -> 
           _execs.getFile(ou == null ? _execs.OUTPUT : ou).println(txt);  
        };
%>;

DEFINE backslash_char=\
DEFINE dollar_char=$

SET termout      ON
PROMPT  
PROMPT  ======================
SHOW USER
PROMPT TIME              is "&v_local_time" 
PROMPT PERIOD            is "&v_period_type"
PROMPT SAMPLE            is "&v_sample_id"
PROMPT PARTITION         is "&v_tpartition"
PROMPT run_tnsname       is "&run_tnsname" 
PROMPT run_country       is "&run_country" 
PROMPT PERIOD_TYPE              is "&v_period_type_char" 
PROMPT  ======================

SET serveroutput ON
SET copycommit    1
SET arraysize  1000
SET timing       ON
SET echo         ON
SET verify       ON

