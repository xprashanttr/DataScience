./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101214 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101215 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101216 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101217 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101218 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101219 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101220 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101221 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101222 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101223 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101224 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101225 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101226 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101227 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101228 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101229 gen_report
./grp.sh -j GRP_ROLLUP -l 7 -e "prashant.tripathi.ap@nielsen.com" -d 101230 gen_report

exit 0

#for dd in 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31
for dd in 01 02 03 04 05 06 07 08 09 10 11
do
echo "--------------------------------------------------------------------------------------------------"
echo "starts for date 201102$dd"

./grp.sh -j GRP_PREPARE_TVPC -s cppweights -l 7 -e "prashant.tripathi.ap@nielsen.com" -d "201102$dd" populate_panel_data 

echo "ends for date 201102$dd"
echo "--------------------------------------------------------------------------------------------------"

done
