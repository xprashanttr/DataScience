DECLARE
   datasource varchar2(64) :='&1';
   exttbl    VARCHAR2 (128) := 'EXT_GRP_'||datasource;
   v_table   VARCHAR2 (128);
BEGIN
   SELECT table_name
     INTO v_table
     FROM user_tables
    WHERE table_name = UPPER (exttbl);
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      EXECUTE IMMEDIATE 'CREATE TABLE '||exttbl||'
    (
    folder_id                      VARCHAR2(30),
    household_id                  VARCHAR2(30)
    )
  ORGANIZATION EXTERNAL (
   DEFAULT DIRECTORY  EXT_GRP_DIR
    ACCESS PARAMETERS(
	    RECORDS DELIMITED BY NEWLINE SKIP 1 CHARACTERSET UTF8
           badfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.bad''
           logfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.log''
           fields terminated BY "|"
           MISSING FIELD VALUES ARE NULL
           REJECT ROWS WITH ALL NULL FIELDS
 )
   LOCATION (
    EXT_GRP_DIR:'''||datasource||'.dat''
   )
  ) REJECT LIMIT 0 ';
END;
/


/*
ideally join should be on folder_id only
but joinnig on household_id also
if mapping changes than previous values: then error will be thrown as folder_id is PK
*/ 

INSERT INTO grp_folder_house_mapping
SELECT DISTINCT folder_id, household_id
           FROM ext_grp_ism_maping a
          WHERE NOT EXISTS (
                   SELECT 1
                     FROM grp_folder_house_mapping b
                    WHERE a.folder_id = b.folder_id
                      AND a.household_id = b.household_id);
COMMIT;

