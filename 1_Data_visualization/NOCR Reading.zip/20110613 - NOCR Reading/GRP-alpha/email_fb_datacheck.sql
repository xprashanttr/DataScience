DELETE FROM pra_ext_grp_facebook;
INSERT INTO pra_ext_grp_facebook
            (local_date, cam_tag, cr_tag, pub_tag, age, gender, uniq_users,
             impressions, frequency)
   SELECT TO_DATE (local_date, 'YYYY-MM-DD'), cam_tag, cr_tag, pub_tag, age,
          gender, uniq_users, impressions, frequency
     FROM ext_grp_facebook;

COMMIT ;

COL c_filename noprint v_filename 
SELECT '&1' c_filename FROM DUAL;

<%

_run.emailTo='Jagdish.Patil@Nielsen.com;Ankur.Tandon.ap@Nielsen.com;Prashant.Tripathi.ap@Nielsen.com'
_run.emailSubject = 'Issue with facebook data file - ' + _run.v_filename

%>;


DEFINE message=_array
DEFINE message= Audience or Impressions are less than previous values : sample

COL _rowset noprint message 
Select * from (
SELECT distinct local_date, cam_tag, pub_tag, age, gender, uniq_users AS curr_usr,
       LAG (uniq_users, 1) OVER (PARTITION BY cam_tag, pub_tag, age, gender ORDER BY local_date)
                                                                   AS prv_usr,
       impressions AS curr_imp,
       LAG (impressions, 1) OVER (PARTITION BY cam_tag, pub_tag, age, gender ORDER BY local_date)
                                                                   AS prv_imp
  FROM (SELECT local_date, cam_tag, pub_tag, age, gender, uniq_users,
               impressions
          FROM pra_ext_grp_facebook
         WHERE cr_tag = 'ALL'
        UNION ALL
        SELECT local_date, encry_cam_tag cam_tag, encry_pub_tag pub_tag, age,
               gender, uniq_users, impressions
          FROM grp_facebook_import a, grp_campaign b, grp_publisher c
         WHERE a.cam_id = b.cam_id
           AND a.pub_id = c.pub_id
           AND cr_tag = 'ALL'
           AND a.local_date IN (SELECT MAX (local_date)
                                  FROM grp_facebook_import)))
 WHERE (curr_usr < prv_usr OR curr_imp < prv_imp)
 AND rownum < 21 ;
 
DEFINE message= Demographics not reported in current file but were reported previously : sample
COL _rowset noprint message 
SELECT *
  FROM (SELECT local_date, encry_cam_tag cam_tag, encry_pub_tag pub_tag, age,
               gender, uniq_users, impressions
          FROM grp_facebook_import a, grp_campaign b, grp_publisher c
         WHERE a.local_date = (SELECT MAX (local_date)
                                 FROM grp_facebook_import)
           AND a.cam_id = b.cam_id
           AND a.pub_id = c.pub_id
           AND cr_tag = 'ALL') a
 WHERE NOT EXISTS (
          SELECT 1
            FROM (SELECT *
                    FROM pra_ext_grp_facebook
                   WHERE cr_tag = 'ALL') b
           WHERE a.cam_tag = b.cam_tag
             AND a.pub_tag = b.pub_tag
             AND a.age = b.age
             AND a.gender = b.gender)
   AND ROWNUM < 10;

DEFINE message= Campaign level impression is not sum of impressions across all publishers
COL _rowset noprint message 
SELECT a.cam_tag, a.age, a.gender, a.imp imp_1, b.imp imp_2
  FROM (SELECT   cam_tag, age, gender, SUM (impressions) imp
            FROM pra_ext_grp_facebook
           WHERE cr_tag = 'ALL' AND pub_tag <> 'ALL'
        GROUP BY cam_tag, age, gender) a,
       (SELECT cam_tag, age, gender, impressions imp
          FROM pra_ext_grp_facebook
         WHERE cr_tag = 'ALL' AND pub_tag = 'ALL') b
 WHERE a.cam_tag = b.cam_tag
   AND a.age = b.age
   AND a.gender = b.gender
   AND a.imp <> b.imp;

DEFINE message= Duplicate records in the file
COL _rowset noprint message 
SELECT   cam_tag, cr_tag, pub_tag, age, gender, uniq_users, impressions,
         COUNT (*) cnt
    FROM pra_ext_grp_facebook
GROUP BY cam_tag, cr_tag, pub_tag, age, gender, uniq_users, impressions
  HAVING COUNT (*) > 1 ;


email message;
