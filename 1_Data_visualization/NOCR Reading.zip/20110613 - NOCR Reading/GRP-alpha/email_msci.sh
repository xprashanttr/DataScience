#!/bin/bash
grphome=`dirname $0`
. $HOME/.profile
. $HOME/prashant/GRP/.email_list 
export TNS_ADMIN=$HOME/prashant/GRP

cd $grphome

sqlsh -u scratch@adrcoll -s d -j campaign_msci -c def -o /adr/core/cfg.ora/phoenix.cfg @"/adr/prashant/GRP/email_msci_report.sql `date '+%Y-%m-%d'`"

