'get_new_pub_cam' )

	#### encryption decryption folder
	encryptfolder="/adr/prashant/fbencrypt"

        #read data source information
        log 5 "reading $grpcfg"
        srcparams="`cat $grpcfg | sed -n "/^$run_src\t/p"`"
        if test -z "$srcparams"
        then
             log 3 "source $run_src not configured"
        fi
        remotelogin=`echo "$srcparams" | awk -F'\t' '{print $3}'`
        remotefolder=`echo "$srcparams" | awk -F'\t' '{print $4}'`
        localfolder=`echo "$srcparams" | awk -F'\t' '{print $5}'`
        donefolder=`echo "$localfolder" | sed 's/in$/done/g'`
        stem=`echo "$srcparams" | awk -F'\t' '{print $2}'`

        log 7 "remotelogin=$remotelogin"
        log 7 "remotefolder=$remotefolder"
        log 7 "localfolder=$localfolder"
        log 7 "donefolder=$donefolder"
        log 7 "stem=$stem"

	## getting list of files in sftp location
	echo "ls -1" > `pwd`/getlistcommand
	sftp -b ./getlistcommand $remotelogin:$remotefolder > `pwd`/get${run_src}filelist.txt

        if test $? -ne 0
        then
           log 3 "sftp authentication failed for $remotelogin"
        fi

        for line in `sed '1,2d' ./get${run_src}filelist.txt | grep -v .cnt`
        do
        #for each file in list, if file not already processed, fetch file
	 echo $line
        if test ! -f "$donefolder/$line"
        then
           filestem="`echo $line | sed 's/\.txt//g'`"
           log 6 "file = $line"
           log 6 "filestem = $filestem"
           log 6 "fetching file $line"

	## copying files to local folder
           sftp $remotelogin:$remotefolder <<EOF_SFTP
                mget $filestem* $localfolder
		  quit
EOF_SFTP

        if test $? -ne 0
        then
           log 3 "sftp copy failed for $remotelogin:$remotefolder/$line data file"
        fi

	if test "run_src" = "facebook"
	then
	# get publishers from file :: publisher is 4th column in both facebook and sitecensus files
	cat $localfolder/$line | awk -F "|" '{print $4}' | sort -u > $encryptfolder/${stem}_pub.txt
	$encryptfolder/fbenc -d -f $encryptfolder/${stem}_pub.txt > $localfolder/${stem}_pub.dat
	####runorasql "@populate_fb_new_pub.sql"

	# get campaigns from file :: campaign is 2nd column in both facebook and sitecensus files
	cat $localfolder/$line | awk -F "|" '{print $2}' | sort -u > $encryptfolder/${stem}_cam.txt
	$encryptfolder/fbenc -d -f $encryptfolder/${stem}_cam.txt > $localfolder/${stem}_cam.dat
	####runorasql "@populate_fb_new_cam.sql"
	fi


	if test "run_src" = "sitecensus"
	then
	# get publishers from file :: publisher is 4th column in both facebook and sitecensus files
	cat $localfolder/$line | awk -F "|" '{print $4}' | sort -u > $encryptfolder/${stem}_pub.txt
	$encryptfolder/fbenc -f $encryptfolder/${stem}_pub.txt > $localfolder/${stem}_pub.dat
	####runorasql "@populate_sc_new_pub.sql"

	# get campaigns from file :: campaign is 2nd column in both facebook and sitecensus files
	cat $localfolder/$line | awk -F "|" '{print $2}' | sort -u > $encryptfolder/${stem}_cam.txt
	$encryptfolder/fbenc -f $encryptfolder/${stem}_cam.txt > $localfolder/${stem}_cam.dat
	####runorasql "@populate_sc_new_cam.sql"
	fi

	rm -f $localfolder/$line

       fi
       done
;;
