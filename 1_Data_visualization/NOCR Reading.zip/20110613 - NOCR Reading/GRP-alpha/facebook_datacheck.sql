WHENEVER oserror exit 1
WHENEVER sqlerror exit 1

DECLARE
   v_dup_rec          INTEGER   := '';
   exc_dup_rec        EXCEPTION;
   v_less_ui          INTEGER   := '';
   exc_less_ui        EXCEPTION;
   v_bad_imp          INTEGER   := '';
   exc_bad_imp        EXCEPTION;
   v_missing_demo     INTEGER   := '';
   exc_missing_demo   EXCEPTION;
BEGIN

   EXECUTE IMMEDIATE 'TRUNCATE TABLE pra_ext_grp_facebook';

   INSERT INTO pra_ext_grp_facebook
               (local_date, cam_tag, cr_tag, pub_tag, age, gender,
                uniq_users, impressions, frequency)
      SELECT TO_DATE (local_date, 'YYYY-MM-DD'), cam_tag, cr_tag, pub_tag,
             age, gender, uniq_users, impressions, frequency
        FROM ext_grp_facebook;

   COMMIT;


-- check for duplicate rows
   SELECT COUNT (*)
     INTO v_dup_rec
     FROM (SELECT   cam_tag, cr_tag, pub_tag, age, gender, uniq_users,
                    impressions, COUNT (*)
               FROM pra_ext_grp_facebook
           GROUP BY cam_tag,
                    cr_tag,
                    pub_tag,
                    age,
                    gender,
                    uniq_users,
                    impressions
             HAVING COUNT (*) > 1);

   IF v_dup_rec > 0
   THEN
      RAISE exc_dup_rec;
   END IF;

-- check if audience or impression are decreased compared to latest loaded file

   SELECT COUNT (*)
     INTO v_less_ui
     FROM (SELECT local_date, cam_tag, pub_tag, age, gender,
                  uniq_users AS curr_usr,
                  LAG (uniq_users, 1) OVER (PARTITION BY cam_tag, pub_tag, age, gender ORDER BY local_date)
                                                                   AS prv_usr,
                  impressions AS curr_imp,
                  LAG (impressions, 1) OVER (PARTITION BY cam_tag, pub_tag, age, gender ORDER BY local_date)
                                                                   AS prv_imp
             FROM (SELECT local_date, cam_tag, pub_tag, age, gender,
                          uniq_users, impressions
                     FROM pra_ext_grp_facebook
                    WHERE cr_tag = 'ALL'
                   UNION ALL
                   SELECT local_date, encry_cam_tag cam_tag,
                          encry_pub_tag pub_tag, age, gender, uniq_users,
                          impressions
                     FROM grp_facebook_import a,
                          grp_campaign b,
                          grp_publisher c
                    WHERE a.cam_id = b.cam_id
                      AND a.pub_id = c.pub_id
                      AND cr_tag = 'ALL'
                      AND a.local_date IN (SELECT MAX (local_date)
                                             FROM grp_facebook_import)))
    WHERE curr_usr < prv_usr OR curr_imp < prv_imp;

   IF v_less_ui > 0
   THEN
      RAISE exc_less_ui;
   END IF;

-- check if impressions reported as pub_tag 'ALL' are sum of impressions reported across all publishers
   SELECT COUNT (*)
     INTO v_bad_imp     --a.cam_tag, a.age, a.gender, a.imp imp_1, b.imp imp_2
     FROM (SELECT   cam_tag, age, gender, SUM (impressions) imp
               FROM pra_ext_grp_facebook
              WHERE cr_tag = 'ALL' AND pub_tag <> 'ALL'
           GROUP BY cam_tag, age, gender) a,
          (SELECT cam_tag, age, gender, impressions imp
             FROM pra_ext_grp_facebook
            WHERE cr_tag = 'ALL' AND pub_tag = 'ALL') b
    WHERE a.cam_tag = b.cam_tag
      AND a.age = b.age
      AND a.gender = b.gender
      AND a.imp <> b.imp;

   IF v_bad_imp > 0
   THEN
      RAISE exc_bad_imp;
   END IF;

-- check if demographic group is not reported
   SELECT COUNT (*)
     INTO v_missing_demo
     FROM (SELECT local_date, encry_cam_tag cam_tag, encry_pub_tag pub_tag,
                  age, gender, uniq_users, impressions
             FROM grp_facebook_import a, grp_campaign b, grp_publisher c
            WHERE a.local_date = (SELECT MAX (local_date)
                                     FROM grp_facebook_import)
              AND a.cam_id = b.cam_id
              AND a.pub_id = c.pub_id
              AND cr_tag = 'ALL') a
    WHERE NOT EXISTS (
             SELECT 1
               FROM (SELECT *
                       FROM pra_ext_grp_facebook
                      WHERE cr_tag = 'ALL') b
              WHERE a.cam_tag = b.cam_tag
                AND a.pub_tag = b.pub_tag
                AND a.age = b.age
                AND a.gender = b.gender);

   IF v_missing_demo > 0
   THEN
      RAISE exc_missing_demo;
   END IF;
-- raising exceptions
EXCEPTION
   WHEN exc_dup_rec
   THEN
      raise_application_error (-20001, 'Duplicate records in the file');
   WHEN exc_less_ui
   THEN
      raise_application_error (-20001, 'Audience Impressions are less than previous day' );
   WHEN exc_bad_imp
   THEN
      raise_application_error (-20001, 'Bad impressions');
   WHEN exc_missing_demo
   THEN
      raise_application_error (-20001, 'Missing demo groups in the file');
END;
/
