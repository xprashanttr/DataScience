DECLARE
   datasource varchar2(64) :='&1';
   exttbl    VARCHAR2 (128) := 'EXT_GRP_TVPC_WEIGHTS';
   v_table   VARCHAR2 (128);
BEGIN

   SELECT table_name
     INTO v_table
     FROM user_tables
    WHERE table_name = UPPER (exttbl);
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
EXECUTE IMMEDIATE 'CREATE TABLE ext_grp_tvpc_weights
  (
CLASS_DATE           VARCHAR2(6),
HHLD_ID              VARCHAR2(11),
PERSON_ID            VARCHAR2(3),
SEX                  VARCHAR2(1),
AGE                  NUMBER,
INTAB_FLAG           VARCHAR2(1),
P_INTAB_FLAG         VARCHAR2(1),
INSTALLED_FLAG       VARCHAR2(1),
WEIGHT              NUMBER,
LTV_INDICATOR        VARCHAR2(1),
METER_TYPE           VARCHAR2(1),
MKT_CODE             NUMBER,
SCALED_WEIGHT        NUMBER,
JIC                  VARCHAR2(2),
CVG                NUMBER,
MKT                NUMBER,
DEMO               NUMBER,
TOTAL_ELEMENTS     NUMBER,
ID_ARRAY         VARCHAR2(550),
FILE_IND             NUMBER,
EXTENDED_HOME_WEIGHT NUMBER
   )
  ORGANIZATION external
  (DEFAULT DIRECTORY EXT_GRP_DIR
    ACCESS PARAMETERS
    ( RECORDS DELIMITED BY NEWLINE SKIP 1 CHARACTERSET UTF8
      badfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.bad''
      logfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.log''
      FIELDS LDRTRIM 
      MISSING FIELD VALUES ARE NULL
      REJECT ROWS WITH ALL NULL FIELDS
        (
CLASS_DATE           (1:6)      CHAR(6),
HHLD_ID              (8:18)     CHAR(11),
PERSON_ID            (20:22)    CHAR(3),
SEX                  (24:24)    CHAR(1),
AGE                  (26:28)    CHAR(3),
INTAB_FLAG           (30:30)    CHAR(1),
P_INTAB_FLAG         (32:32)    CHAR(1),
INSTALLED_FLAG       (34:34)    CHAR(1),
WEIGHT               (36:46)    CHAR(11),
LTV_INDICATOR        (48:48)     CHAR(1),
METER_TYPE           (50:50)    CHAR(1),
MKT_CODE             (52:54)     CHAR(3),
SCALED_WEIGHT        (56:63)     CHAR(8),
JIC                  (65:66)     CHAR(2),
CVG                 (68:77)      CHAR(10),
MKT                 (79:88)      CHAR(10),
DEMO                (90:99)      CHAR(10),
TOTAL_ELEMENTS      (101:110)    CHAR(10),
ID_ARRAY             (112:661)     CHAR(550),
FILE_IND             (663:665)    CHAR(3),
EXTENDED_HOME_WEIGHT (667:667)    CHAR(1)
        ))
    location ( EXT_GRP_DIR:'''||datasource||'.dat'' )
  ) REJECT LIMIT 0 ' ;

END;
/

-- commented for now
-- this procedure will populate weight information in GRP_PANEL_WEIGHT table
exec xgrp.populate_grp_panel_weight ;

