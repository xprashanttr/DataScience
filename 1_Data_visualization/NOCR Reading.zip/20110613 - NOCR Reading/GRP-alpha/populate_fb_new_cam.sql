DECLARE
   datasource varchar2(64) :='&1';
   exttbl    VARCHAR2 (128) := 'EXT_GRP_'||datasource||'_CAM';
   v_table   VARCHAR2 (128);
BEGIN
   SELECT table_name
     INTO v_table
     FROM user_tables
    WHERE table_name = UPPER (exttbl);
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
EXECUTE IMMEDIATE'CREATE TABLE '||exttbl||'
    (enc_cam_tag                    VARCHAR2(100),
    dec_cam_tag                    VARCHAR2(100))
  ORGANIZATION EXTERNAL (
   DEFAULT DIRECTORY  EXT_GRP_DIR
    ACCESS PARAMETERS(RECORDS DELIMITED BY NEWLINE CHARACTERSET utf8
           BADFILE ext_grp_dir:'''||datasource||'_new_cam%a_%p.bad''
           LOGFILE ext_grp_dir:'''||datasource||'_new_cam%a_%p.log''
           FIELDS TERMINATED BY "->"
           MISSING FIELD VALUES ARE NULL
           REJECT ROWS WITH ALL NULL FIELDS
 )
   LOCATION (
    EXT_GRP_DIR:'''||datasource||'_cam.dat''
   )
  )';

END;
/

INSERT INTO grp_campaign
            (cam_tag, cam_start_date, cam_end_date, encry_cam_tag)
   SELECT TRIM (dec_cam_tag), TRUNC (SYSDATE) - 10, TRUNC (SYSDATE) + 90, TRIM (enc_cam_tag)
     FROM ext_grp_fb_cam a
    WHERE NOT EXISTS (
             SELECT 1
               FROM grp_campaign b
              WHERE TRIM (a.dec_cam_tag) = TRIM (b.cam_tag)
                AND TRIM (a.enc_cam_tag) = TRIM (b.encry_cam_tag));

COMMIT ;
