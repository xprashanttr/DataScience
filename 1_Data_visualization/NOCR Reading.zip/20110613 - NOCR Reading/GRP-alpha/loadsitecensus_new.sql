DECLARE
   datasource varchar2(64) :='&1';
   exttbl    VARCHAR2 (128) := 'EXT_GRP_'||datasource;
   v_table   VARCHAR2 (128);
BEGIN
   SELECT table_name
     INTO v_table
     FROM user_tables
    WHERE table_name = UPPER (exttbl);
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
      EXECUTE IMMEDIATE 'CREATE TABLE '||exttbl||'
   (
	local_date                     VARCHAR2(10),
	cam_tag                        VARCHAR2(64),
	mv_treeid		  	   INTEGER,
	site_id                        VARCHAR2(128),
	dma_id                         NUMBER,    
	impressions                    NUMBER(15,0),
	uniq_cookies                   NUMBER(15,0),
       region                         VARCHAR2(7)
   )
  ORGANIZATION EXTERNAL (
   DEFAULT DIRECTORY  EXT_GRP_DIR
    ACCESS PARAMETERS(RECORDS delimited BY newline CHARACTERSET UTF8
           badfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.bad''
           logfile EXT_GRP_DIR:'''||datasource||'_ext%a_%p.log''
           fields terminated BY "|"
           OPTIONALLY ENCLOSED BY ''"''
           MISSING FIELD VALUES ARE NULL
           REJECT ROWS WITH ALL NULL FIELDS
 )
   LOCATION (
    EXT_GRP_DIR:'''||datasource||'.dat''
   )
  )';
END;
/

/*
DELETE FROM grp_sitecensus_import
      WHERE local_date IN 
      (SELECT DISTINCT TO_DATE (local_date, 'YYYY-MM-DD')
                                      FROM ext_grp_sitecensus );
*/

DELETE FROM grp_sitecensus_import a
      WHERE EXISTS (SELECT 1 FROM 
                    (SELECT DISTINCT TO_DATE (local_date, 'YYYY-MM-DD') local_date, cam_id
                                  FROM ext_grp_sitecensus b JOIN grp_campaign c
                                       ON (b.cam_tag = c.cam_tag)) x
                WHERE x.local_date = a.local_date AND x.cam_id = a.cam_id);

-- new column "region"
INSERT INTO grp_sitecensus_import
            (local_date, pub_id, cam_id, impressions, uniq_cookies, region)
   SELECT TO_DATE (local_date, 'YYYY-MM-DD') local_date, pub_id, cam_id,
          impressions, uniq_cookies, region
     FROM ext_grp_sitecensus a JOIN grp_campaign b ON b.cam_tag = a.cam_tag
          JOIN grp_publisher s ON s.pub_tag = a.site_id ;

COMMIT ;

-- insert into grp_campaign_total table
BEGIN
   FOR idate IN (SELECT DISTINCT local_date
                            FROM ext_grp_sitecensus
                        ORDER BY local_date)
   LOOP
      xgrp.prepare_sitecensus (TO_DATE (idate.local_date, 'YYYY-MM-DD'));
   END LOOP;
END;
/
