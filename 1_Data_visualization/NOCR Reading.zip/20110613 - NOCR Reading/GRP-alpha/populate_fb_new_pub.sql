DECLARE
   datasource varchar2(64) :='&1';
   exttbl    VARCHAR2 (128) := 'EXT_GRP_'||datasource||'_PUB';
   v_table   VARCHAR2 (128);
BEGIN
   SELECT table_name
     INTO v_table
     FROM user_tables
    WHERE table_name = UPPER (exttbl);
EXCEPTION
   WHEN NO_DATA_FOUND
   THEN
EXECUTE IMMEDIATE'CREATE TABLE '||exttbl||'
    (enc_pub_tag                    VARCHAR2(100),
    dec_pub_tag                    NVARCHAR2(100))
  ORGANIZATION EXTERNAL (
   DEFAULT DIRECTORY  EXT_GRP_DIR
    ACCESS PARAMETERS(RECORDS DELIMITED BY NEWLINE CHARACTERSET utf8
           BADFILE ext_grp_dir:'''||datasource||'_new_pub%a_%p.bad''
           LOGFILE ext_grp_dir:'''||datasource||'_new_pub%a_%p.log''
           FIELDS TERMINATED BY "->"
           MISSING FIELD VALUES ARE NULL
           REJECT ROWS WITH ALL NULL FIELDS
 )
   LOCATION (
    EXT_GRP_DIR:'''||datasource||'_pub.dat''
   )
  )';

END;
/

INSERT INTO grp_publisher
            (pub_tag, encry_pub_tag)
   SELECT TRIM (a.dec_pub_tag), TRIM (a.enc_pub_tag)
     FROM ext_grp_fb_pub a
    WHERE TRIM (a.enc_pub_tag) <> 'ALL'
      AND NOT EXISTS (
             SELECT 1
               FROM grp_publisher b
              WHERE TRIM (a.dec_pub_tag) = TRIM (b.pub_tag)
                AND TRIM (a.enc_pub_tag) = TRIM (b.encry_pub_tag));
COMMIT ;
