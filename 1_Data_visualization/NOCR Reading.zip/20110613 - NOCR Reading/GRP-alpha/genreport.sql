exec xgrp.grp_report(to_date(substr(trim('&1'),-6,6),'YYMMDD'));
