#!/bin/bash
name=`basename $0`
grphome=`dirname $0`
. $HOME/.profile
. $HOME/prashant/GRP/.email_list 

#### encryption decryption folder
encryptfolder="/adr/prashant/fbencrypt"

export TNS_ADMIN=$HOME/prashant/GRP

cd $grphome
mypid=$$
#echo $mypid

usage()
{
echo "fill-in later..."
}

function log {
####################################
# please follow syslog like priorities for logging
# 0 - Emerg
# 1 - Alert
# 2 - Crit
# 3 - Err
# 4 - Warning
# 5 - Notice
# 6 - Info
# 7 - Debug
####################################
case $1 in
1|2|3 ) status_label="ERROR: "
;;
*) status_label=""
;;
esac

if [ $1 -le $run_debug_level ] 
then
echo "`date '+%Y-%m-%d %H.%M.%S'` : $1 : $run_cmjobname : $name : $status_label$2" | tee -a $logfile $weblogfile 
fi

if [ $1 -le 3 ] 
then
#echo "$2" | mail -s "ERROR:$run_cmjobname:$name failed on `hostname`.Please see $logfile for more details" "$error_email"
sed "1,/$start_msg/d" $logfile | mail -s "$status_label$run_cmjobname:$name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}

function log_err_nofail {
echo "`date '+%Y-%m-%d %H.%M.%S'` : 3 : $run_cmjobname : $name : $1" | tee -a $logfile $weblogfile
}


function get_pw {
cat .dbpw |tr [:lower:] [:upper:] |awk '{if ($1==dbusr && $3==dbname) print $2}' dbusr="`echo $1 | tr [:lower:] [:upper:]`" dbname="`echo $2 | tr [:lower:] [:upper:]`"
}


function runorasql {

dbpasswd="`get_pw $dbusr $dbname`"

if test -z "$dbpasswd"
then
log 3  "passwd not known for $dbusr@$dbname contact database administrator"
fi

#log 6 "run $1 on $dbusr@$dbname" commented 4-jan-2011
log 6 "connecting to db $dbusr@$dbname"

oralog="/tmp/$mypid`date +'%s'`.tmp"

sqlplus -S /NOLOG << eof++ >> $oralog
whenever oserror exit 1
whenever sqlerror exit 1
set heading off;
connect $dbusr/$dbpasswd@$dbname
$1
exit;
eof++
exit_status=$?

if test $exit_status  -ne 0
then
log_err_nofail "--- oracle log from $oralog ----"
cat $oralog | sed '/^$/d' | while read errline
do
log_err_nofail "$errline"
done
log 3 "Oracle error"
else
log 5 "see oracle log in $oralog"
fi

}

while getopts ":j:d:l:s:o:m:e:" opt; do
  case $opt in
    j  ) run_cmjobname="`echo $OPTARG| sed 's/^ *//'`"  ;;
    d  ) run_date="`echo $OPTARG| sed 's/^ *//'`" ;;
    e  ) run_email="`echo $OPTARG| sed 's/^ *//'`";;
    l  ) run_debug_level="`echo $OPTARG| sed 's/^ *//'`";;
    s  ) run_src="`echo $OPTARG| sed 's/^ *//'`";;
    m  ) run_mode="`echo $OPTARG| sed 's/^ *//'`";;
    o  ) run_output="`echo $OPTARG| sed 's/^ *//'`";;
    \? ) usage ;;
  esac
done

shift $(($OPTIND - 1))

if [ $# -eq 0 ]; then
  usage
fi

run_opr="`echo $* | sed 's/^ *//'`"

if test -z  $run_debug_level 
then
run_debug_level=5
fi

if test -z "$run_email" 
then
error_email=$EMAIL_ERR
email=$EMAIL
else
email=$run_email
error_email=$run_email
fi

if test -z "$run_mode"
then
run_mode="dev"
fi

if test -z "$run_output"
then
logfile="$grphome/$name.log"
else
logfile="$run_output"
fi

if test -n "$run_cmjobname"
then
#weblogfolder="$grphome/weblog"
weblogfolder="/adr/jagdish/GRP/weblog"
weblogfile="$weblogfolder/$run_cmjobname.`date +'%s'`.log"
fi

start_msg=`log 5 "start pid=$mypid"`
starttime="`date +'%s'`"

log 6 "pid=$mypid"
log 6 "sourc=$run_src"
log 6 "operation=$run_opr"
log 6 "err_email=$error_email"
log 6 "run_mode=$run_mode"
log 6 "run_output=$run_output"
log 6 "run_date=$run_date"

case $run_mode in
'dev' ) dbusr="scratch"
        dbname="adrcoll"
        grpcfg="`pwd`/grpdev.cfg"
;;
'prod') dbusr="scratch"
        dbname="adrcoll"
        #grpcfg="`pwd`/grp.cfg"  #prashant2dec
        grpcfg="`pwd`/grpdev.cfg"
;;
* ) log 3 "unknown run mode"
;;
esac

if test ! -e "$grpcfg"
then
log 3 "grp config file $grpcfg does not exist"
fi

case $run_opr in
'get_new_pub_cam' )

        #read data source information
        log 5 "reading $grpcfg"
        srcparams="`cat $grpcfg | sed -n "/^$run_src\t/p"`"
        if test -z "$srcparams"
        then
             log 3 "source $run_src not configured"
        fi
        remotelogin=`echo "$srcparams" | awk -F'\t' '{print $3}'`
        remotefolder=`echo "$srcparams" | awk -F'\t' '{print $4}'`
        localfolder=`echo "$srcparams" | awk -F'\t' '{print $5}'`
        donefolder=`echo "$localfolder" | sed 's/in$/done/g'`
        stem=`echo "$srcparams" | awk -F'\t' '{print $2}'`

        log 7 "remotelogin=$remotelogin"
        log 7 "remotefolder=$remotefolder"
        log 7 "localfolder=$localfolder"
        log 7 "stem=$stem"

	## getting list of files in sftp location
	echo "ls -1 $stem*" > `pwd`/getlistcommand
	sftp -b ./getlistcommand $remotelogin:$remotefolder > `pwd`/get${run_src}filelist.txt

        if test $? -ne 0
        then
           log 3 "sftp authentication failed for $remotelogin"
        fi

        for line in `sed '1,2d' ./get${run_src}filelist.txt | grep -v .cnt`
        do
        #for each file in list, if file not already processed, fetch file
	 echo $line
        if test ! -f "$donefolder/$line"
        then
           filestem="`echo $line | sed 's/\.txt//g'`"
           log 6 "file = $line"
           log 6 "filestem = $filestem"
           log 6 "fetching file $line"

	## copying files to local folder
           sftp $remotelogin:$remotefolder <<EOF_SFTP
                mget $filestem* $localfolder
		  quit
EOF_SFTP

        if test $? -ne 0
        then
           log 3 "sftp copy failed for $remotelogin:$remotefolder/$line data file"
        fi

	if test "$run_src" = "facebook"
	then
       log 6 "getting publishers from $run_src file $line"
	#publisher is 4th column in both facebook and sitecensus files

	##excluding "644f36b1d5a47837f59630e3" because of bad encrypted tag "��|���G���ȯJ��"
cat $localfolder/$line | awk -F "|" '{print $4}' | sort -u | grep -v "ALL" | grep -v "644f36b1d5a47837f59630e3" | grep -v "d1hQAFsGBw__644f36b1db9051d67e79150f" > $encryptfolder/${stem}_pub.txt

       log 6 "decrypting publishers from $run_src file $line"
	$encryptfolder/fbenc -d -f $encryptfolder/${stem}_pub.txt > $localfolder/${stem}_pub.dat
       log 6 "populating new publishers starts"
	runorasql "@populate_fb_new_pub.sql $stem"
       log 6 "new publishers population done"

	#campaign is 2nd column in both facebook and sitecensus files
       log 6 "getting campaigns from $run_src file $line"
	cat $localfolder/$line | awk -F "|" '{print $2}' | sort -u > $encryptfolder/${stem}_cam.txt
       log 6 "decrypting campaigns from $run_src file $line"
	$encryptfolder/fbenc -d -f $encryptfolder/${stem}_cam.txt > $localfolder/${stem}_cam.dat
       log 6 "populating new campaigns starts"
	runorasql "@populate_fb_new_cam.sql $stem"
       log 6 "populating new campaigns done"
	fi

	
	if test "$run_src" = "sitecensus"
	then
       log 6 "getting publishers from $run_src file $line"
	#publisher is 4th column in both facebook and sitecensus files
	cat $localfolder/$line | awk -F "|" '{print $4}' | sort -u | grep -v "ALL" > $encryptfolder/${stem}_pub.txt
       #log 6 "encrypting publishers from $run_src file $line" ## encryption should be done from oracle function only: confirm with Jagdish
	##$encryptfolder/fbenc -f $encryptfolder/${stem}_pub.txt > $localfolder/${stem}_pub.dat
	cp $encryptfolder/${stem}_pub.txt $localfolder/${stem}_pub.dat

       log 6 "populating new publishers starts"
	runorasql "@populate_sc_new_pub.sql $stem"
       log 6 "populating new publishers ends"

	#campaign is 2nd column in both facebook and sitecensus files
       log 6 "getting campaigns from $run_src file $line"
	cat $localfolder/$line | awk -F "|" '{print $2}' | sort -u > $encryptfolder/${stem}_cam.txt
       log 6 "encrypting campaigns from $run_src file $line" ## encryption should be done from oracle function only: confirm with Jagdish
	##$encryptfolder/fbenc -f $encryptfolder/${stem}_cam.txt > $localfolder/${stem}_cam.dat
	cp $encryptfolder/${stem}_cam.txt $localfolder/${stem}_cam.dat

       log 6 "populating new campaigns starts"
	runorasql "@populate_sc_new_cam.sql $stem"
       log 6 "populating new campaigns ends"
	fi

## remove data file : this has to be loaded 
	rm -f $localfolder/$line
       fi
       done
	echo "New pub cam import done for $run_src file" | mail -s "NOCR Notification : New pub cam import done for $run_src file" "$EMAIL"
;;

'get' )
        #read data source information
        log 5 "reading $grpcfg"
        srcparams="`cat $grpcfg | sed -n "/^$run_src\t/p"`"
        if test -z "$srcparams"
        then
             log 3 "source $run_src not configured"
        fi
        remotelogin=`echo "$srcparams" | awk -F'\t' '{print $3}'`
        remotefolder=`echo "$srcparams" | awk -F'\t' '{print $4}'`
        localfolder=`echo "$srcparams" | awk -F'\t' '{print $5}'`
        donefolder=`echo "$localfolder" | sed 's/in$/done/g'`
        stem=`echo "$srcparams" | awk -F'\t' '{print $2}'`
        sqlfile=`echo "$srcparams" | awk -F'\t' '{print $6}'`
        zipfolder=`echo "$srcparams" | awk -F'\t' '{print $7}'`
        log 7 "remotelogin=$remotelogin"
        log 7 "remotefolder=$remotefolder"
        log 7 "localfolder=$localfolder"
        log 7 "donefolder=$donefolder"
        log 7 "stem=$stem"
        log 7 "sqlfile=$sqlfile"
        log 7 "zipfolder=$zipfolder"

	## getting list of files in sftp location
	echo "ls -1 $stem*" > `pwd`/getlistcommand
	sftp -b ./getlistcommand $remotelogin:$remotefolder > `pwd`/get${run_src}filelist.txt

        if test $? -ne 0
        then
           log 3 "sftp authentication failed for $remotelogin"
        fi

        for line in `sed '1,2d' ./get${run_src}filelist.txt | grep -v .cnt`
        do
        #for each file in list, if file not already processed, fetch file
	 echo $line
        if test ! -f "$donefolder/$line"
        then
           filestem="`echo $line | sed 's/\.txt//g'`"
           log 6 "file = $line"
           log 6 "filestem = $filestem"
           log 6 "fetching file $line"

	## copying files to local folder
           sftp $remotelogin:$remotefolder <<EOF_SFTP
                mget $filestem* $localfolder
		  quit
EOF_SFTP

        if test $? -ne 0
        then
           log 3 "sftp copy failed for $remotelogin:$remotefolder/$line data file"
        fi

         #check for existance of file
           if test ! -e "$localfolder/$line" -o ! -e "$localfolder/$filestem.cnt"
           then
		echo "$line|`cat $localfolder/$line | wc -l`" > $localfolder/$filestem.cnt
              ## log 3 "file missing" ## commented as facebook is not reporting cnt files
           fi

           #count lines in file
	    cfstats="`wc -l $localfolder/$line | sed 's/^[ ]//g' | awk '{print $1}'`"

		log 7 "$line line $cfstats"

          #read checker file
	    rsig="`head -1 $localfolder/$filestem.cnt | awk -F "|" '{print $2}'`"

		if test "$rsig" != "$cfstats"
           then
              mv $localfolder/$line $localfolder/$line.err
              log 3 "$line integrity failure"
           else
              log 5 "$line fetched successfully"
           fi
           if test -n "$sqlfile"
           then
               log 6 "loading file $localfolder/$line to database"
               #copy data file as <source>.dat to avoid drop/create oracle external table every time
               cp $localfolder/$line "$localfolder/$run_src.dat"
	        runorasql "@$sqlfile $run_src $line"  ## second parameter added for facebook datacheck script.
               log 5 "loaded file $localfolder/$line to database"
               #truncate <source>.dat file as load is complete
               #:> "$localfolder/$run_src.dat"

		##zip folder movement shouild be done here
		if test -n "$zipfolder"
		then
		zip -j $localfolder/$line.zip $localfolder/$line
		mv $localfolder/$line.zip $zipfolder
		fi

		#notify mail
		echo "Successfully loaded $run_src file : $line" | mail -s "NOCR Notification : Successfully loaded $run_src file : $line " "$EMAIL"
              mv $localfolder/$filestem* $donefolder
           fi
        fi
        done
;;
'import_tvpc') log 5 "get tvpc data"
          runorasql "@tvpcimport.sql $run_date"
          log 5 "tvpc import done" 
;;


############################################################################
## New job to pull panel data and process weight files together

'populate_panel_data') 
	 log 5 "import tvpc data for date $run_date"
        #runorasql "@tvpcimport.sql $run_date"
        runorasql "exec xgrp.import_tvpc(TRUNC (to_date(substr(trim('$run_date'),-6,6),'YYMMDD')))"
	 log 5 "tvpc import done for date $run_date" 

	 log 5 "process tvpc weights"
        log 5 "reading $grpcfg"
        srcparams="`cat $grpcfg | sed -n "/^$run_src\t/p"`"
        if test -z "$srcparams"
        then
             log 3 "source $run_src not configured"
        fi
        remotelogin=`echo "$srcparams" | awk -F'\t' '{print $3}'`
        remotefolder=`echo "$srcparams" | awk -F'\t' '{print $4}'`
        localfolder=`echo "$srcparams" | awk -F'\t' '{print $5}'`
        donefolder=`echo "$localfolder" | sed 's/in$/done/g'`
        stem=`echo "$srcparams" | awk -F'\t' '{print $2}'`
        sqlfile=`echo "$srcparams" | awk -F'\t' '{print $6}'`
        log 7 "remotelogin=$remotelogin"
        log 7 "remotefolder=$remotefolder"
        log 7 "localfolder=$localfolder"
        log 7 "donefolder=$donefolder"
        log 7 "stem=$stem"
        log 7 "sqlfile=$sqlfile"
        log 7 "run_date=$run_date"

	 wgtfile="$stem`date -d $run_date +%y``date -d $run_date +%j`"
        log 7 "weight_file=$wgtfile"

        #get listing ofg files from remote server
        filelist=`ssh $remotelogin "cd $remotefolder;ls -1 $wgtfile*" 2>> $weblogfile`
        if test $? -ne 0
        then
           log 3 "ssh authentication failed for $remotelogin"
        fi
        for line in $filelist
        do

        ###if test ! -f "$donefolder/$line" -----------------------------we need to reprocess the file while rerun
        ###then
           filestem="`echo $line | sed 's/\.txt//g'`"
           log 6 "fetching file $line"
           #fetch file from remote server
           scp -q $remotelogin:$remotefolder/$filestem* $localfolder
           #check for existance of file
           if test ! -e "$localfolder/$line"
           then
              log 3 "file missing"
           fi
           log 5 "$line fetched successfully"
           if test -n "$sqlfile"
           then
               log 6 "loading file $localfolder/$line to database"
               #copy data file as <source>.dat to avoid drop/create oracle external table every time
               cp $localfolder/$line "$localfolder/$run_src.dat"
               runorasql "@$sqlfile $run_src"
               log 5 "runorasql $sqlfile $run_src"
               log 5 "loaded file $localfolder/$line to database"
               #truncate <source>.dat file as load is complete
               #:> "$localfolder/$run_src.dat"
               mv $localfolder/$filestem* $donefolder
           fi
        ###fi

        done

        log 5 "tvpc weight process done"

#populate grp_campaign_data and grp_campaign_total tables for panel data
	   log 5 "aggregate tvpc for $run_date"
          ##runorasql "@tvpcpopulate.sql $run_date"
          runorasql "exec xgrp.aggregate_tvpc(TRUNC (to_date(substr(trim('$run_date'),-6,6),'YYMMDD')))"
	   log 5 "tvpc aggregation done for $run_date"
          echo "Panel data loaded for $run_date" | mail -s "NOCR Notification : Panel data loaded for $run_date" "$EMAIL_ERR"
;;

############################################################################


'gen_report') log 5 "generate report"
          runorasql "@genreport.sql $run_date"
          log 5 "generate report done" 
          echo "grp_report done for $run_date" | mail -s "NOCR Notification : grp_report done for $run_date" "$EMAIL_ERR"
;;
'get_cppweights' ) log 5 "get tvpc weights"
        #read data source information
        log 5 "reading $grpcfg"
        srcparams="`cat $grpcfg | sed -n "/^$run_src\t/p"`"
        if test -z "$srcparams"
        then
             log 3 "source $run_src not configured"
        fi
        remotelogin=`echo "$srcparams" | awk -F'\t' '{print $3}'`
        remotefolder=`echo "$srcparams" | awk -F'\t' '{print $4}'`
        localfolder=`echo "$srcparams" | awk -F'\t' '{print $5}'`
        donefolder=`echo "$localfolder" | sed 's/in$/done/g'`
        stem=`echo "$srcparams" | awk -F'\t' '{print $2}'`
        sqlfile=`echo "$srcparams" | awk -F'\t' '{print $6}'`
        log 7 "remotelogin=$remotelogin"
        log 7 "remotefolder=$remotefolder"
        log 7 "localfolder=$localfolder"
        log 7 "donefolder=$donefolder"
        log 7 "stem=$stem"
        log 7 "sqlfile=$sqlfile"
        log 5 "get $run_src files from $remotelogin"
        #get listing ofg files from remote server
        filelist=`ssh $remotelogin "cd $remotefolder;ls -1 $stem*" 2>> $weblogfile`
        if test $? -ne 0
        then
           log 3 "ssh authentication failed for $remotelogin"
        fi
        for line in $filelist
        do
        #for each file in list, if file not already processed, fetch file
        if test ! -f "$donefolder/$line"
        then
           filestem="`echo $line | sed 's/\.txt//g'`"
           log 6 "fetching file $line"
           #fetch file from remote server
           scp -q $remotelogin:$remotefolder/$filestem* $localfolder
           #check for existance of file
           if test ! -e "$localfolder/$line"
           then
              log 3 "file missing"
           fi
           log 5 "$line fetched successfully"
           if test -n "$sqlfile"
           then
               log 6 "loading file $localfolder/$line to database"
               #copy data file as <source>.dat to avoid drop/create oracle external table every time
               cp $localfolder/$line "$localfolder/$run_src.dat"
               runorasql "@$sqlfile $run_src"
               log 5 "runorasql $sqlfile $run_src"
               log 5 "loaded file $localfolder/$line to database"
               #truncate <source>.dat file as load is complete
               #:> "$localfolder/$run_src.dat"
               mv $localfolder/$filestem* $donefolder
           fi
        fi
        done
;;

'get_ism_mapping') 
#log 5 "get ism mapping"
#runorasql "@loadismmapping.sql"
#sleep 30
#log 5 "ism maping done" 

        #read data source information
        log 5 "reading $grpcfg"
        srcparams="`cat $grpcfg | sed -n "/^$run_src\t/p"`"
        if test -z "$srcparams"
        then
             log 3 "source $run_src not configured"
        fi
        remotelogin=`echo "$srcparams" | awk -F'\t' '{print $3}'`
        remotefolder=`echo "$srcparams" | awk -F'\t' '{print $4}'`
        localfolder=`echo "$srcparams" | awk -F'\t' '{print $5}'`
        donefolder=`echo "$localfolder" | sed 's/in$/done/g'`
        stem=`echo "$srcparams" | awk -F'\t' '{print $2}'`
        sqlfile=`echo "$srcparams" | awk -F'\t' '{print $6}'`
        log 7 "remotelogin=$remotelogin"
        log 7 "remotefolder=$remotefolder"
        log 7 "localfolder=$localfolder"
        log 7 "donefolder=$donefolder"
        log 7 "stem=$stem"
        log 7 "sqlfile=$sqlfile"
        log 5 "get $run_src files from $remotelogin"

        #get listing ofg files from remote server
        filelist=`ssh $remotelogin "cd $remotefolder;ls -1 $stem*" 2>> $weblogfile`
        if test $? -ne 0
        then
           log 3 "ssh authentication failed for $remotelogin"
        fi
        for line in $filelist
        do
        #for each file in list, if file not already processed, fetch file
        if test ! -f "$donefolder/$line"
        then
           filestem="`echo $line | sed 's/\.txt//g'`"
           log 6 "fetching file $line"
           #fetch file from remote server
           scp -q $remotelogin:$remotefolder/$filestem* $localfolder
           #check for existance of file
           if test ! -e "$localfolder/$line"
           then
              log 3 "file missing"
           fi
           log 5 "$line fetched successfully"
           if test -n "$sqlfile"
           then
               log 6 "loading file $localfolder/$line to database"
               #copy data file as <source>.dat to avoid drop/create oracle external table every time
               ########cp $localfolder/$line "$localfolder/$run_src.dat"
		 cut -d '|' -f 1,2 $localfolder/$line > "$localfolder/$run_src.dat"
               runorasql "@$sqlfile $run_src"
               log 5 "runorasql $sqlfile $run_src"
               log 5 "loaded file $localfolder/$line to database"
               #truncate <source>.dat file as load is complete
               #:> "$localfolder/$run_src.dat"
               mv $localfolder/$filestem* $donefolder
           fi
        fi
        done


;;

* ) log 3 "unknown operation" 
exit 1
;;
esac

endtime="`date +'%s'`"

log 5 "Elasped time `expr $endtime - $starttime` seconds"
log 5 "done pid=$mypid"
