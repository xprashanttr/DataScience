. ~adrusr/.profile

export TNS_ADMIN=/adr/prashant/GRP

v_notify="Prashant.Tripathi.ap@nielsen.com"

echo "script starts at `date`"

PUBTAGNULL_COUNT=`sqlplus -S scratch/scratch@adrcoll << eofa
  set head off
  set feedback off
  set pages
  select count(1) from scratch.grp_publisher where pub_tag is null AND encry_pub_tag <> 'd1hQAFsGBw__644f36b1db9051d67e79150f' ;
eofa`

if test $PUBTAGNULL_COUNT -ne 0
then
     echo "PUB_TAG in grp_publisher is null ! Please check " | mail -s "NOCR Alert: PUB_TAG in grp_publisher is null " "$v_notify"
fi

ENCRY_PUBNULL_COUNT=`sqlplus -S scratch/scratch@adrcoll << eofa
  set head off
  set feedback off
  set pages
  select count(1) from scratch.grp_publisher where ENCRY_PUB_TAG is null ;
eofa`

if test $ENCRY_PUBNULL_COUNT -ne 0
then
     echo "ENCRY_PUB_TAG in grp_publisher is null ! Please check " | mail -s "NOCR Alert: ENCRY_PUB_TAG in grp_publisher is null " "$v_notify"
fi

CAMTAGNULL_COUNT=`sqlplus -S scratch/scratch@adrcoll << eofa
  set head off
  set feedback off
  set pages
  select count(1) from scratch.grp_campaign where cam_tag is null ;
eofa`

if test $CAMTAGNULL_COUNT -ne 0
then
     echo "CAM_TAG in grp_campaign is null ! Please check " | mail -s "NOCR Alert: CAM_TAG in grp_campaign is null " "$v_notify"
fi

ENCRY_CAMNULL_COUNT=`sqlplus -S scratch/scratch@adrcoll << eofa
  set head off
  set feedback off
  set pages
  select count(1) from scratch.grp_campaign where ENCRY_CAM_TAG is null ;
eofa`

if test $ENCRY_CAMNULL_COUNT -ne 0
then
     echo "ENCRY_CAM_TAG in grp_campaign is null ! Please check " | mail -s "NOCR Alert: ENCRY_CAM_TAG in grp_campaign is null " "$v_notify"
fi

echo "script ends at `date`"
exit 0
