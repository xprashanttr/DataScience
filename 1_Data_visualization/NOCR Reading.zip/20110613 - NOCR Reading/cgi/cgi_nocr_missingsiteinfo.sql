set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;

select issue from nocr_derror_type where issue_id = &1 ;

column c_sdate noprint new_value v_sdate
column c_edate noprint new_value v_edate

select '&2' c_sdate, '&3' c_edate from dual;

select decode(&4,0,'<p align="right"><a href="./grp_derrordownloadreport?&1,&2,&3">Export to excel</a></p>','') from dual;

select '<table border=1>
<tr bgcolor="silver" align="center" width="100%" >
<td>local_date</td>
<td>cam_id</td>
<td>cam_name</td>
<td>cam_tag</td>
<td>encry_cam_tag</td>
<td>pub_id</td>
<td>pub_tag</td>
<td>encry_pub_tag</td>
<td>pub_name</td>
</tr>' from dual;


select '<tr>
<td align="left">'||local_date||'</td>
<td align="left">'||cam_id||'</td>
<td align="left">'||cam_name||'</td>
<td align="left">'||cam_tag||'</td>
<td align="left">'||encry_cam_tag||'</td>
<td align="left">'||pub_id||'</td>
<td align="left">'||pub_tag||'</td>
<td align="left">'||encry_pub_tag||'</td>
<td align="left">'||pub_name||'</td>
</tr>'
FROM (
SELECT   local_date, cam_id,cam_name,
         cam_tag, encry_cam_tag, p.pub_id,
         pub_tag, encry_pub_tag, pub_name
    FROM (SELECT *
            FROM grp_campaign_total
           WHERE local_date >= to_date(&v_sdate,'YYYYMMDD')
 	      AND local_date <= to_date(&v_edate,'YYYYMMDD')) a
         JOIN
         (SELECT *
            FROM grp_publisher
           WHERE pub_tag IS NULL OR encry_pub_tag IS NULL OR pub_name IS NULL) p
         ON (a.pub_id = p.pub_id)
         JOIN grp_campaign c ON (a.cam_id = c.cam_id))
ORDER BY local_date DESC, cam_id DESC, pub_id;

select '</table></td>
</tr>
</table>'
FROM DUAL;

