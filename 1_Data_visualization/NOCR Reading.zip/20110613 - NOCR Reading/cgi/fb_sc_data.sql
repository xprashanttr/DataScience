WHENEVER SQLERROR EXIT 1;
WHENEVER OSERROR EXIT 2;
set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;
set termout off;
--input parameters yyyymmdd filename
column c_filename noprint new_value vfilename
select 'FB_SC_REPORT'||to_char(sysdate,'yyyymmdd') c_filename from dual;
spool &vfilename..csv
select txt from 
(select 1 rec_type, ('local_date' ||'|'||'cam_name' ||'|'|| 'cam_tag'||'|'||'encry_cam_tag'||'|'||'site_name'||'|'||'pub_tag'||'|'||'encry_pub_tag'||'|'||
'sc_impressions'||'|'||'fb_impressions'||'|'||'pan_impressions'||'|'||'sc_minus_fb_impr'||'|'||
'fb_perc_sc_impr'||'|'||'sc_audience'||'|'||'fb_audience'||'|'||'pan_audience'||'|'||'sc_minus_fb_aud'||'|'||'fb_perc_sc_aud'||'|'|| 
'issue_type') txt  from dual
union all
select 2 rec_type,(local_date ||'|'||cam_name ||'|'|| cam_tag||'|'||encry_cam_tag||'|'||site_name||'|'||pub_tag||'|'||encry_pub_tag||'|'||sc_impressions||'|'||fb_impressions||'|'||pan_impressions||'|'||sc_minus_fb_impr||'|'||
fb_perc_sc_impr||'|'||sc_audience||'|'||fb_audience||'|'||pan_audience||'|'||sc_minus_fb_aud||'|'||fb_perc_sc_aud||'|'|| 
decode(issue_type,1,'DATA missing from one of the source',2,'FB more than SC',3,'FB missing lots of impressions','OTHER ISSUE')) txt
from v_fb_sc_data
) order by rec_type;
spool off;

