set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;

select issue from nocr_derror_type where issue_id = &1 ;
column c_sdate noprint new_value v_sdate
column c_edate noprint new_value v_edate
select '&2' c_sdate, '&3' c_edate from dual;

select decode(&4,0,'<p align="right"><a href="./grp_derrordownloadreport?&1,&2,&3">Export to excel</a></p>','') from dual;

select '<table border=1>
<tr bgcolor="silver" align="center" width="100%" >
<td>local_date</td>
<td>fb_cam_count</td>
<td>sc_cam_count</td>
</tr>' from dual;

select '<tr bgcolor='||case when fb_cam_count > sc_cam_count then '"red"'
when fb_cam_count < sc_cam_count then '"yellow"' end||
'><td align="left">'||TO_CHAR (local_date, 'YYYY-MM-DD')||'</td>
<td align="left">'||fb_cam_count||'</td>
<td align="left">'||sc_cam_count||'</td>
</tr>'
from (
SELECT   local_date, MAX (fb_cam) fb_cam_count, MAX (sc_cam) sc_cam_count
       FROM (SELECT   local_date,
                      COUNT (DISTINCT (DECODE (ds_id, 1, cam_id))) fb_cam,
                      COUNT (DISTINCT (DECODE (ds_id, 2, cam_id))) sc_cam
                 FROM grp_campaign_total
                WHERE ds_id IN (1, 2)
                  AND local_date >= to_date(&v_sdate,'YYYYMMDD')
                  AND local_date <= to_date(&v_edate,'YYYYMMDD')
             GROUP BY local_date, ds_id
             ORDER BY local_date DESC)
   GROUP BY local_date)
ORDER BY local_date DESC;

select '</table></td>
</tr>
</table>'
FROM DUAL;
