set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;

column c_sdate noprint new_value v_sdate

select '&1' c_sdate from dual;

select '<form action="./grp_fb_impusr?" method="get">
date : <SELECT name="sdate" >
<OPTION selected ></OPTION>' from dual;

select * from (
select distinct '<OPTION value="'||to_char(local_date,'YYYYMMDD')||
'">'||to_char(local_date,'DD-MON-YYYY')||'</OPTION>'
 from grp_campaign_total WHERE local_date > '15-NOV-2010'
) order by 1 desc ;

select '</SELECT>
<input type="submit" name="go" value="go"/>
</form>' from dual;

select '<table border=1>
<tr bgcolor="silver" align="center" width="100%" >
<td>local_date</td>
<td>cam_name</td>
<td>cam_tag</td>
<td>encry_cam_tag</td>
<td>site_name</td>
<td>pub_tag</td>
<td>encry_pub_tag</td>
<td>age</td>
<td>gender</td>
<td>curr_usr</td>
<td>prv_usr</td>
<td>curr_imp</td>
<td>prv_imp</td>
</tr>' from dual;

select '<tr>
<td align="right">'||local_date||'</td>
<td align="right">'||cam_name||'</td>
<td align="right">'||cam_tag||'</td>
<td align="right">'||encry_cam_tag||'</td>
<td align="right">'||site_name||'</td>
<td align="right">'||pub_tag||'</td>
<td align="right">'||encry_pub_tag||'</td>
<td align="right">'||age||'</td>
<td align="right">'||gender||'</td>
<td align="right">'||curr_usr||'</td>
<td align="right">'||prv_usr||'</td>
<td align="right">'||curr_imp||'</td>
<td align="right">'||prv_imp||'</td>
</tr>'
from
(SELECT DISTINCT local_date, cam_name, cam_tag, encry_cam_tag,
                          site_name, pub_tag, encry_pub_tag, age, gender,
                          uniq_users AS curr_usr,
                          LAG (uniq_users, 1) OVER (PARTITION BY cam_name, cam_tag, encry_cam_tag, site_name, pub_tag, encry_pub_tag, age, gender ORDER BY local_date)
                                                                   AS prv_usr,
                          impressions AS curr_imp,
                          LAG (impressions, 1) OVER (PARTITION BY cam_name, cam_tag, encry_cam_tag, site_name, pub_tag, encry_pub_tag, age, gender ORDER BY local_date)
                                                                   AS prv_imp
                     FROM (SELECT local_date, cam_name, cam_tag,
                                  encry_cam_tag, pub_name site_name, pub_tag,
                                  encry_pub_tag, age, gender, uniq_users,
                                  impressions
                             FROM grp_facebook_import a,
                                  grp_campaign b,
                                  grp_publisher c
                            WHERE a.local_date >= to_date(&v_sdate,'YYYYMMDD') -2
                              AND a.cam_id = b.cam_id
                              AND a.pub_id = c.pub_id
                              AND a.pub_id <> 1
                              AND cr_tag = 'ALL'))
   WHERE (curr_usr < prv_usr OR curr_imp < prv_imp)
     AND local_date = to_date(&v_sdate,'YYYYMMDD')
ORDER BY cam_name, site_name, age, gender, local_date;


select '</table></td>
</tr>
</table>'
FROM DUAL;

