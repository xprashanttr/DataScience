set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;


select '<table border=1>
<tr bgcolor="silver" align="center" width="50%" >
<td width=40>local_date</td>
<td width=10>cam_name</td>
<td width=10>cam_tag</td>
<td width=10>encry_cam_tag</td>
<td width=10>pub_tag</td>
<td width=10>pub_name</td>
<td width=10>encry_pub_tag</td>
<td>sc_impressions</td>
<td>fb_impressions</td>
<td>pan_impressions</td>
<td>sc_minus_fb_impr</td>
<td>fb_perc_sc_impr</td>
<td>sc_audience</td>
<td>fb_audience</td>
<td>pan_audience</td>
<td>sc_minus_fb_aud</td>
<td>fb_perc_sc_aud</td>
</tr>' from dual;

select '<tr bgcolor='||case when issue_type=1 then '"grey"' WHEN issue_type=2 then '"yellow"' WHEN issue_type=2 then '"red"' end||
'><td align="left">'||local_date||'</td>
<td align="left">'||cam_name||'</td>
<td align="left">'||cam_tag||'</td>
<td align="left">'||encry_cam_tag||'</td>
<td align="left">'||pub_tag||'</td>
<td align="left">'||site_name||'</td>
<td align="left">'||encry_pub_tag||'</td>
<td align="right">'||sc_impressions||'</td>
<td align="right">'||fb_impressions||'</td>
<td align="right">'||pan_impressions||'</td>
<td align="right">'||sc_minus_fb_impr||'</td>
<td align="right">'||fb_perc_sc_impr||'</td>
<td align="right">'||sc_audience||'</td>
<td align="right">'||fb_audience||'</td>
<td align="right">'||pan_audience||'</td>
<td align="right">'||sc_minus_fb_aud||'</td>
<td align="right">'||fb_perc_sc_aud||'</td>
</tr>'
from v_fb_sc_data;

select '</table></td>
</tr>
</table>'
FROM DUAL;

