#!/bin/bash
cd `dirname $0`
name=`basename $0`
logfile="$1_$2_$name.log"
. ~adrusr/.profile
. /adr/prashant/GRP/.email_list
export TNS_ADMIN=/adr/prashant/GRP

mypid=$$

#echo $mypid

start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"
echo $start_msg >> $logfile

function log {
echo "`date '+%Y-%m-%d %H.%M.%S'`: $1: $name: $2" >> $logfile

if test $1 -le 3
then
sed "1,/$start_msg/d" $logfile | mail -s "ERROR:$name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}

function get_pw {
cat .pw |tr [:lower:] [:upper:] |awk '{if ($1==dbusr && $3==dbname) print $2}' dbusr="`echo $1 | tr [:lower:] [:upper:]`" dbname="`echo $2 | tr [:lower:] [:upper:]`"
}

log 5 "start $0 $*"

if test -n "$4"
then
#overwrite error email list
error_email="$4"
else
error_email="$EMAIL_GRP_ERROR"
fi

#echo "error_email=$error_email"

case $2 in
'prd') dbname="prdcoll"
       ;;
'stg') dbname="stgcoll"
       ;;
'dev') dbname="adrcoll"
      ;;
'stgtool') dbname="stgtools"
      ;;
'prdtool') dbname="prdtools"
      ;;
'ntrtui') dbname="ntrtui"
      ;;
'loadus') dbname="loadus_cbts"
     ;;
'anaus') dbname="anaus_cbts"
     ;;
*) log 3 "ERROR:unknown environment"
     ;;
esac

case $1 in
'kr')dbusr="adr_kr"
     ;;
'us')dbusr="adr_us"
     ;;
'eu')dbusr="adr_eu"
     ;;
'jp')dbusr="adr_jp"
     ;;
'br')dbusr="adr_br"
     ;;
'cn')dbusr="adr_cn"
     ;;
'za')dbusr="adr_za"
     ;;
'oz')dbusr="adr_oz"
     ;;
'mb')dbusr="adr_mb"
     ;;
'in')dbusr="adr_in"
     ;;
'tw')dbusr="adr_tw"
     ;;
'all')dbusr="adr_kr adr_us adr_eu adr_jp adr_br adr_cn adr_za adr_oz adr_mb adr_in adr_tw"
     ;;
'def')dbusr="adr_def"
    ;;
'bo')dbusr="adrbo"
    ;;
'scratch')dbusr="scratch"
    ;;
'cis')dbusr="adr_cis"
    ;;
'nnviewer') dbusr="nnviewer"
    ;;
'dataqa') dbusr="dataqa"
   ;;
*) log 3 "ERROR:unknown dbuser"
     ;;
esac

for thisdbusr in $dbusr
do
dbpasswd="`get_pw $thisdbusr $dbname`"
#echo "$dbpasswd"

if test -z "$dbpasswd"
then
log 3  "ERROR:passwd not known for $thisdbusr@$dbname contact database administrator"
fi

log 5 "connecting to db $thisdbusr@$dbname"
sqlplus -S /NOLOG << eof++
set heading off; 
connect $thisdbusr/$dbpasswd@$dbname
$3
exit;
eof++
exit_status=$?
if test $exit_status  -ne 0
then
log 3 "ERROR:Oracle error"
fi

done

log 5 "done $0 $*"
