set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;

select issue from nocr_derror_type where issue_id = &1 ;

select decode(&4,0,'<p align="right"><a href="./grp_derrordownloadreport?&1,&2,&3">Export to excel</a></p>','') from dual;

select '<table border=1>
<tr bgcolor="silver" align="center" width="100%" >
<td>cam_id</td>
<td>cam_tag</td>
<td>cam_start_date</td>
<td>cam_end_date</td>
<td>encry_cam_tag</td>
<td>cam_name</td>
</tr>' from dual;

select '<tr>
<td align="left">'||cam_id||'</td>
<td align="left">'||cam_tag||'</td>
<td align="left">'||cam_start_date||'</td>
<td align="left">'||cam_end_date||'</td>
<td align="left">'||encry_cam_tag||'</td>
<td align="left">'||cam_name||'</td>
</tr>'
	FROM grp_campaign
	   WHERE cam_tag IS NULL
	      OR cam_end_date IS NULL
	      OR encry_cam_tag IS NULL
	      OR cam_name IS NULL
	ORDER BY cam_id;

select '</table></td>
</tr>
</table>'
FROM DUAL;

