set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;

column c_sdate noprint new_value v_sdate
column c_edate noprint new_value v_edate

select '&1' c_sdate, '&2' c_edate from dual;

select '<form action="./grp_fbsc?" method="get">
start_date : <SELECT name="sdate" >
<OPTION selected ></OPTION>' from dual;

select * from (
select distinct '<OPTION value="'||to_char(local_date,'YYYYMMDD')||
'">'||to_char(local_date,'DD-MON-YYYY')||'</OPTION>'
 from grp_campaign_total WHERE local_date > '15-NOV-2010'
) order by 1 desc ;

select '</SELECT>
end_date :<SELECT name="edate">
<OPTION selected ></OPTION>' from dual;

select * from (
select distinct '<OPTION value="'||to_char(local_date,'YYYYMMDD')||
'">'||to_char(local_date,'DD-MON-YYYY')||'</OPTION>'
 from grp_campaign_total WHERE local_date > '15-NOV-2010'
) order by 1 desc ;

select '</SELECT>
<input type="submit" name="go" value="go"/>
</form>' from dual;

select '<table border=1>
<tr bgcolor="silver" align="center" width="100%" >
<td>local_date</td>
<td>cam_name</td>
<td>cam_tag</td>
<td>encry_cam_tag</td>
<td>site_name</td>
<td>pub_tag</td>
<td>encry_pub_tag</td>
<td>sc_impressions</td>
<td>fb_impressions</td>
</tr>' from dual;

select '<tr bgcolor='||case when sc_impressions < fb_impressions then '"yellow"' WHEN (fb_impressions = 0 or sc_impressions = 0) then '"red"' end||
'><td>'||local_date||'</td>
<td align="right">'||cam_name||'</td>
<td align="right">'||cam_tag||'</td>
<td align="right">'||encry_cam_tag||'</td>
<td align="right">'||site_name||'</td>
<td align="right">'||pub_tag||'</td>
<td align="right">'||encry_pub_tag||'</td>
<td align="right">'||sc_impressions||'</td>
<td align="right">'||fb_impressions||'</td>
</tr>'
from
(
select local_date, cam_name, cam_tag, encry_cam_tag, 
site_name, pub_tag, encry_pub_tag, 
sum(decode(ds_id,2,impression,0)) sc_impressions ,
sum(decode(ds_id,1,impression,0)) fb_impressions
 from (
select local_date, ds_id, cam_name,  pub_name, nvl(pub_name, pub_tag) site_name, cam_tag, encry_cam_tag, pub_tag, encry_pub_tag, impression
from grp_campaign_total a, grp_campaign b, grp_publisher c where ds_id=1 
and b.cam_id=a.cam_id 
and c.pub_id=a.pub_id
and a.pub_id > 1
union
select local_date, ds_id, cam_name, pub_name, nvl(pub_name, pub_tag) site_name, cam_tag, encry_cam_tag, pub_tag, encry_pub_tag, impression
from grp_campaign_total a, grp_campaign b, grp_publisher c where ds_id=2 
and b.cam_id=a.cam_id 
and c.pub_id=a.pub_id
and a.pub_id > 1
) WHERE local_date >= to_date(&v_sdate,'YYYYMMDD')
		 AND local_date <= to_date(&v_edate,'YYYYMMDD')
group by local_date, cam_name, site_name, cam_tag, encry_cam_tag, pub_tag, encry_pub_tag
) 
order by local_date desc, cam_name, site_name;


select '</table></td>
</tr>
</table>'
FROM DUAL;
