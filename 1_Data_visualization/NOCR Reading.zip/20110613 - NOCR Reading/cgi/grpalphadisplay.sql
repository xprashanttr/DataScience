select '<form action="./grpalphaderror?" method="get">' from dual;

select 'data : <SELECT name="itype" >
<OPTION selected ></OPTION>' from dual;

select 
'<OPTION value="'||issue_id||'">'||issue_id||'.'||issue||'</OPTION>' from 
nocr_derror_type  order by issue_id;

select '</SELECT>
start_date :<SELECT name="sdate">
<OPTION selected ></OPTION>' from dual;

select * from (
select distinct '<OPTION value="'||to_char(local_date,'YYYYMMDD')||
'">'||to_char(local_date,'DD-MON-YYYY')||'</OPTION>'
 from grp_campaign_total WHERE local_date >= '1-JAN-2011'
) order by 1 desc ;

select '</SELECT>
end_date :<SELECT name="edate">
<OPTION selected ></OPTION>' from dual;

select * from (
select distinct '<OPTION value="'||to_char(local_date,'YYYYMMDD')||
'">'||to_char(local_date,'DD-MON-YYYY')||'</OPTION>'
 from grp_campaign_total WHERE local_date >= '1-JAN-2011'
) order by 1 desc ;


select '</SELECT>
<input type="submit" name="go" value="go"/>
</form>' from dual;
