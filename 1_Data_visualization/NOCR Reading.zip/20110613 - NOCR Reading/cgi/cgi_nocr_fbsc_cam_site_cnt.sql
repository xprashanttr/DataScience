set verify off;
set heading off;
set feedback off;
set linesize 10000;
set pagesize 0;
set trimspool on;

select issue from nocr_derror_type where issue_id = &1 ;

column c_sdate noprint new_value v_sdate
column c_edate noprint new_value v_edate
select '&2' c_sdate, '&3' c_edate from dual;

select decode(&4,0,'<p align="right"><a href="./grp_derrordownloadreport?&1,&2,&3">Export to excel</a></p>','') from dual;

select '<table border=1>
<tr bgcolor="silver" align="center" width="100%" >
<td>local_date</td>
<td>cam_id</td>
<td>cam_tag</td>
<td>encry_cam_tag</td>
<td>cam_name</td>
<td>fb_site_count</td>
<td>sc_site_count</td>
<td>pnl_site_count</td>
</tr>' from dual;


select '<tr bgcolor='||case when fb_pub_count > sc_pub_count then '"red"'
when fb_pub_count < sc_pub_count then '"yellow"' end||
'><td align="left">'||local_date||'</td>
<td align="left">'||cam_id||'</td>
<td align="left">'||cam_tag||'</td>
<td align="left">'||encry_cam_tag||'</td>
<td align="left">'||cam_name||'</td>
<td align="left">'||fb_pub_count||'</td>
<td align="left">'||sc_pub_count||'</td>
<td align="left">'||pnl_pub_count||'</td>
</tr>'
from (
SELECT   local_date, a.cam_id, cam_tag, encry_cam_tag, cam_name,
         MAX (fb_pub) fb_pub_count, MAX (sc_pub) sc_pub_count,
         MAX (pn_pub) pnl_pub_count
    FROM (SELECT   local_date, cam_id,
                   COUNT (DISTINCT DECODE (ds_id, 1, pub_id)) fb_pub,
                   COUNT (DISTINCT DECODE (ds_id, 2, pub_id)) sc_pub,
                   COUNT (DISTINCT DECODE (ds_id, 3, pub_id)) pn_pub
              FROM grp_campaign_total
             WHERE local_date >= to_date(&v_sdate,'YYYYMMDD')
		 AND local_date <= to_date(&v_edate,'YYYYMMDD')
		 AND pub_id <> 1
          GROUP BY local_date, cam_id, ds_id) a
         JOIN
         grp_campaign b ON (a.cam_id = b.cam_id)
GROUP BY local_date, a.cam_id, cam_tag, encry_cam_tag, cam_name
) order by local_date desc,cam_id desc;

select '</table></td>
</tr>
</table>'
FROM DUAL;
