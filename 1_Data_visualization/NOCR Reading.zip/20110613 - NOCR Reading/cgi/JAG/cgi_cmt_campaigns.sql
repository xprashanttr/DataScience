set verify off;
set heading off;
set feedback off;
set linesize 1000;
set pagesize 0;

select '<table width="1920">' from dual;
select '<tr bgcolor="#82CAFF" align="center"><td>sr. no</td><td>start date</td><td>end date</td><td>campaign id</td><td>encr campaign id</td><td>campaign name</td><td>ad server name</td>'||
'<td>advertiser name</td><td>brand name</td><td>campaign status</td></tr>' from dual;

select 
--rnumber,
--case when mod(rnumber,2)=0 then 'even' else '' end txtbackground,
--case when upper(campaign_status )='CANCELED' then 'red' when  start_date > sysdate then 'blue' when  end_date < sysdate  then 'green' else '' end txtcolor,
'<tr class="'||case when mod(rnumber,2)=0 then 'even' else '' end||case when upper(campaign_status )='CANCELED' then 'red' when  start_date > sysdate then 'blue' when  end_date < sysdate  then 'green' else '' end ||'">'||
'<td align="center">'||rnumber||'</td>'||
'<td>'||to_char(start_date,'yyyy-mm-dd')||'</td>'||
'<td>'||to_char(end_date,'yyyy-mm-dd')||'</td>'||
'<td>'||campaign_id||' (<a href="./cmt_placements?'||campaign_id||'">p</a>) (<a href="./cmt_placement_trend?'||campaign_id||'">pt</a>) (<a href="./cmt_campaign_trend?'||campaign_id||'">ct</a>)</td>'||
'<td>'||fbencrypt(campaign_id)||'</td>'||
'<td>'||campaign_name||'</td>'||
'<td>'||ad_server_name||'</td>'||
'<td>'||advertiser_name||'</td>'||
'<td>'||brand_name||'</td>'||
'<td>'||campaign_status||'</td>'||
'</tr>' txt
 from (
SELECT campaign_id,
       campaign_name,
       ad_server_name,
       advertiser_name,
       brand_name,
       campaign_status,
       start_date,
       end_date,
       rank() OVER (ORDER BY case when start_date > sysdate then end_date  when end_date > sysdate then sysdate  else start_date end desc , campaign_id ) rnumber
FROM (SELECT DISTINCT 
             campaign_id campaign_id,
             campaign_name,
             ad_server_name,
             advertiser_name,
             brand_name,
             MIN(UPPER(placement_status)) OVER (PARTITION BY campaign_id) campaign_status,
             MIN(planned_start_date) OVER (PARTITION BY campaign_id) start_date,
             MAX(planned_end_date) OVER (PARTITION BY campaign_id) end_date
      FROM placement_details_cmt) x
  )
order by rnumber
;
select '</table>' from dual;
