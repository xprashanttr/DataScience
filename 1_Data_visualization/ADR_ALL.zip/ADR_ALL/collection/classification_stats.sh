#!/bin/bash
/adr/jagdish/deployment.sh bo prdtool "@classification_stat.sql"
/adr/jagdish/deployment.sh bo stgtool "@classification_stat.sql"
