-- Start of DDL Script for View ADR_DEF.NAVIGATION_ALL_VIEW
-- Generated 25-Feb-2010 16:38:00 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW navigation_all_view (
   id,
   active,
   site_id,
   username,
   country_id,
   password )
AS
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_us.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_eu.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_oz.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_jp.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_kr.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_tw.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_br.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_in.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_cn.navigation_account
union all
select "ID","ACTIVE","SITE_ID","USERNAME","COUNTRY_ID","PASSWORD" from adr_za.navigation_account
/

-- Grants for View
GRANT SELECT ON navigation_all_view TO public
/

-- End of DDL Script for View ADR_DEF.NAVIGATION_ALL_VIEW

-- Start of DDL Script for View ADR_DEF.V_AD_EXT
-- Generated 25-Feb-2010 16:38:09 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_ad_ext (
   itime,
   ad_status_id,
   ad_width,
   ad_height,
   ad_size,
   dest_loc_url,
   md5,
   property_id,
   ad_directory,
   ad_name,
   ad_target_redirection_type,
   platform_id,
   technology_id,
   md5_meter,
   debug_flag )
AS
SELECT  TO_DATE (itime, 'dd-mon-yyyy hh24:mi:ss') itime,
        case when technology_id in (2,3,4,7) then 1 when REGEXP_INSTR(trim(dest_loc_url),'^http://.+\..+') = 1 then 2 else 1 end ad_status_id,
        ad_width, ad_height, ad_size, TRIM(replace(dest_loc_url,CHR(0),'')) dest_loc_url, md5, property_id, ad_directory,
        TRIM(ad_name) ad_name, ad_target_redirection_type, platform_id, technology_id, REPLACE (md5_meter, CHR (13), '') md5_meter,DEBUG_FLAG
     FROM ADR_DEF.ad_ext
/


-- End of DDL Script for View ADR_DEF.V_AD_EXT

-- Start of DDL Script for View ADR_DEF.V_AD_INSTANCES_EXT
-- Generated 25-Feb-2010 16:38:17 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_ad_instances_ext (
   fetch_id,
   result_id,
   delivery_type,
   targeting,
   patrn_id,
   primary_target_domain,
   ad_platform_id,
   original_location,
   final_location,
   original_target_url,
   country_code_id,
   md5,
   technology_id,
   itime,
   click_flag )
AS
SELECT fetch_id, result_id, delivery_type, targeting, patrn_id,
          primary_target_domain, ad_platform_id, original_location,
          final_location, original_target_url, country_code_id, md5,
          technology_id, TO_DATE (itime, 'dd-mon-yyyy hh24:mi:ss') itime, click_flag
     FROM adr_def.ad_instances_ext
/


-- End of DDL Script for View ADR_DEF.V_AD_INSTANCES_EXT

-- Start of DDL Script for View ADR_DEF.V_AD_INSTANCES_WITH_ERROR
-- Generated 25-Feb-2010 16:38:24 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_ad_instances_with_error (
   owner,
   fetch_id,
   result_id,
   delivery_type,
   targeting,
   patrn_id,
   primary_target_domain,
   ad_platform_id,
   original_location,
   final_location,
   original_target_url,
   country_code_id,
   md5,
   technology_id,
   itime,
   job_id,
   click_flag )
AS
SELECT 'ADR_TW' owner, adr_tw."FETCH_ID",adr_tw."RESULT_ID",adr_tw."DELIVERY_TYPE",adr_tw."TARGETING",adr_tw."PATRN_ID",adr_tw."PRIMARY_TARGET_DOMAIN",adr_tw."AD_PLATFORM_ID",adr_tw."ORIGINAL_LOCATION",adr_tw."FINAL_LOCATION",adr_tw."ORIGINAL_TARGET_URL",adr_tw."COUNTRY_CODE_ID",adr_tw."MD5",adr_tw."TECHNOLOGY_ID",adr_tw."ITIME",adr_tw."JOB_ID",adr_tw."CLICK_FLAG"
     FROM adr_tw.ad_instances_with_error adr_tw
   UNION ALL
   SELECT 'ADR_US', adr_us."FETCH_ID",adr_us."RESULT_ID",adr_us."DELIVERY_TYPE",adr_us."TARGETING",adr_us."PATRN_ID",adr_us."PRIMARY_TARGET_DOMAIN",adr_us."AD_PLATFORM_ID",adr_us."ORIGINAL_LOCATION",adr_us."FINAL_LOCATION",adr_us."ORIGINAL_TARGET_URL",adr_us."COUNTRY_CODE_ID",adr_us."MD5",adr_us."TECHNOLOGY_ID",adr_us."ITIME",adr_us."JOB_ID",adr_us."CLICK_FLAG"
     FROM adr_us.ad_instances_with_error adr_us
   UNION ALL
   SELECT 'ADR_JP', adr_jp."FETCH_ID",adr_jp."RESULT_ID",adr_jp."DELIVERY_TYPE",adr_jp."TARGETING",adr_jp."PATRN_ID",adr_jp."PRIMARY_TARGET_DOMAIN",adr_jp."AD_PLATFORM_ID",adr_jp."ORIGINAL_LOCATION",adr_jp."FINAL_LOCATION",adr_jp."ORIGINAL_TARGET_URL",adr_jp."COUNTRY_CODE_ID",adr_jp."MD5",adr_jp."TECHNOLOGY_ID",adr_jp."ITIME",adr_jp."JOB_ID",adr_jp."CLICK_FLAG"
     FROM adr_jp.ad_instances_with_error adr_jp
   UNION ALL
   SELECT 'ADR_OZ', adr_oz."FETCH_ID",adr_oz."RESULT_ID",adr_oz."DELIVERY_TYPE",adr_oz."TARGETING",adr_oz."PATRN_ID",adr_oz."PRIMARY_TARGET_DOMAIN",adr_oz."AD_PLATFORM_ID",adr_oz."ORIGINAL_LOCATION",adr_oz."FINAL_LOCATION",adr_oz."ORIGINAL_TARGET_URL",adr_oz."COUNTRY_CODE_ID",adr_oz."MD5",adr_oz."TECHNOLOGY_ID",adr_oz."ITIME",adr_oz."JOB_ID",adr_oz."CLICK_FLAG"
     FROM adr_oz.ad_instances_with_error adr_oz
   UNION ALL
   SELECT 'ADR_BR', adr_br."FETCH_ID",adr_br."RESULT_ID",adr_br."DELIVERY_TYPE",adr_br."TARGETING",adr_br."PATRN_ID",adr_br."PRIMARY_TARGET_DOMAIN",adr_br."AD_PLATFORM_ID",adr_br."ORIGINAL_LOCATION",adr_br."FINAL_LOCATION",adr_br."ORIGINAL_TARGET_URL",adr_br."COUNTRY_CODE_ID",adr_br."MD5",adr_br."TECHNOLOGY_ID",adr_br."ITIME",adr_br."JOB_ID",adr_br."CLICK_FLAG"
     FROM adr_br.ad_instances_with_error adr_br
   UNION ALL
   SELECT 'ADR_EU', adr_eu."FETCH_ID",adr_eu."RESULT_ID",adr_eu."DELIVERY_TYPE",adr_eu."TARGETING",adr_eu."PATRN_ID",adr_eu."PRIMARY_TARGET_DOMAIN",adr_eu."AD_PLATFORM_ID",adr_eu."ORIGINAL_LOCATION",adr_eu."FINAL_LOCATION",adr_eu."ORIGINAL_TARGET_URL",adr_eu."COUNTRY_CODE_ID",adr_eu."MD5",adr_eu."TECHNOLOGY_ID",adr_eu."ITIME",adr_eu."JOB_ID",adr_eu."CLICK_FLAG"
     FROM adr_eu.ad_instances_with_error adr_eu
   UNION ALL
   SELECT 'ADR_KR', adr_kr."FETCH_ID",adr_kr."RESULT_ID",adr_kr."DELIVERY_TYPE",adr_kr."TARGETING",adr_kr."PATRN_ID",adr_kr."PRIMARY_TARGET_DOMAIN",adr_kr."AD_PLATFORM_ID",adr_kr."ORIGINAL_LOCATION",adr_kr."FINAL_LOCATION",adr_kr."ORIGINAL_TARGET_URL",adr_kr."COUNTRY_CODE_ID",adr_kr."MD5",adr_kr."TECHNOLOGY_ID",adr_kr."ITIME",adr_kr."JOB_ID",adr_kr."CLICK_FLAG"
     FROM adr_kr.ad_instances_with_error adr_kr
   UNION ALL
   SELECT 'ADR_IN', adr_in."FETCH_ID",adr_in."RESULT_ID",adr_in."DELIVERY_TYPE",adr_in."TARGETING",adr_in."PATRN_ID",adr_in."PRIMARY_TARGET_DOMAIN",adr_in."AD_PLATFORM_ID",adr_in."ORIGINAL_LOCATION",adr_in."FINAL_LOCATION",adr_in."ORIGINAL_TARGET_URL",adr_in."COUNTRY_CODE_ID",adr_in."MD5",adr_in."TECHNOLOGY_ID",adr_in."ITIME",adr_in."JOB_ID",adr_in."CLICK_FLAG"
     FROM adr_in.ad_instances_with_error adr_in
   UNION ALL
   SELECT 'ADR_CN', adr_cn."FETCH_ID",adr_cn."RESULT_ID",adr_cn."DELIVERY_TYPE",adr_cn."TARGETING",adr_cn."PATRN_ID",adr_cn."PRIMARY_TARGET_DOMAIN",adr_cn."AD_PLATFORM_ID",adr_cn."ORIGINAL_LOCATION",adr_cn."FINAL_LOCATION",adr_cn."ORIGINAL_TARGET_URL",adr_cn."COUNTRY_CODE_ID",adr_cn."MD5",adr_cn."TECHNOLOGY_ID",adr_cn."ITIME",adr_cn."JOB_ID",adr_cn."CLICK_FLAG"
     FROM adr_cn.ad_instances_with_error adr_cn
   UNION ALL
   SELECT 'ADR_ZA', adr_za."FETCH_ID",adr_za."RESULT_ID",adr_za."DELIVERY_TYPE",adr_za."TARGETING",adr_za."PATRN_ID",adr_za."PRIMARY_TARGET_DOMAIN",adr_za."AD_PLATFORM_ID",adr_za."ORIGINAL_LOCATION",adr_za."FINAL_LOCATION",adr_za."ORIGINAL_TARGET_URL",adr_za."COUNTRY_CODE_ID",adr_za."MD5",adr_za."TECHNOLOGY_ID",adr_za."ITIME",adr_za."JOB_ID",adr_za."CLICK_FLAG"
     FROM adr_za.ad_instances_with_error adr_za
   UNION ALL
   SELECT 'ADR_MB', adr_mb."FETCH_ID",adr_mb."RESULT_ID",adr_mb."DELIVERY_TYPE",adr_mb."TARGETING",adr_mb."PATRN_ID",adr_mb."PRIMARY_TARGET_DOMAIN",adr_mb."AD_PLATFORM_ID",adr_mb."ORIGINAL_LOCATION",adr_mb."FINAL_LOCATION",adr_mb."ORIGINAL_TARGET_URL",adr_mb."COUNTRY_CODE_ID",adr_mb."MD5",adr_mb."TECHNOLOGY_ID",adr_mb."ITIME",adr_mb."JOB_ID",adr_mb."CLICK_FLAG"
     FROM adr_mb.ad_instances_with_error adr_mb
/

-- Grants for View
GRANT SELECT ON v_ad_instances_with_error TO public
/

-- End of DDL Script for View ADR_DEF.V_AD_INSTANCES_WITH_ERROR

-- Start of DDL Script for View ADR_DEF.V_ADMINER_DAILY_STATS
-- Generated 25-Feb-2010 16:38:32 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_adminer_daily_stats (
   owner,
   type,
   "today",
   "today-1" )
AS
SELECT   owner, TYPE, SUM (DECODE (itime,TRUNC (SYSDATE), rcount, 0 )) "today",
         SUM (DECODE (itime, TRUNC (SYSDATE) - 1, rcount, 0)) "today-1"
    FROM (SELECT   owner, TYPE, TRUNC (itime) itime, COUNT (1) cnt,
                   SUM (actual_dts_rec) rcount
              FROM v_all_adminer_job
             WHERE itime > TRUNC (SYSDATE) - 1
          GROUP BY owner, TYPE, TRUNC (itime))
GROUP BY owner, TYPE
order by owner, TYPE
/

-- Grants for View
GRANT SELECT ON v_adminer_daily_stats TO public
/

-- End of DDL Script for View ADR_DEF.V_ADMINER_DAILY_STATS

-- Start of DDL Script for View ADR_DEF.V_ADMINER_JOB
-- Generated 25-Feb-2010 16:38:40 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_adminer_job (
   id,
   type,
   itime,
   filename,
   status,
   row_count,
   actual_dts_rec,
   country_code )
AS
SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'us' country_code
     FROM adr_us.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'eu' country_code
     FROM adr_eu.adminer_job
    WHERE status = 1
    UNION ALL
    SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'oz' country_code
     FROM adr_oz.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'jp' country_code
     FROM adr_jp.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'kr' country_code
     FROM adr_kr.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'tw' country_code
     FROM adr_tw.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'br' country_code
     FROM adr_br.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'in' country_code
     FROM adr_in.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'cn' country_code
     FROM adr_cn.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'za' country_code
     FROM adr_za.adminer_job
    WHERE status = 1
   UNION ALL
   SELECT ID, TYPE, itime, filename, status, row_count, actual_dts_rec, 'mb' country_code
     FROM adr_mb.adminer_job
    WHERE status = 1
/


-- End of DDL Script for View ADR_DEF.V_ADMINER_JOB

-- Start of DDL Script for View ADR_DEF.V_ADMINER_WEEKLY_STAT
-- Generated 25-Feb-2010 16:38:47 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_adminer_weekly_stat (
   type,
   "today",
   "today-1",
   "today-2",
   "today-3",
   "today-4",
   "today-5",
   "today-6",
   "today-7" )
AS
SELECT   TYPE, SUM (DECODE (itime, TRUNC (SYSDATE), rcount, 0)) "today",
            SUM (DECODE (itime, TRUNC (SYSDATE) - 1, rcount, 0)) "today-1",
            SUM (DECODE (itime, TRUNC (SYSDATE) - 2, rcount, 0)) "today-2",
            SUM (DECODE (itime, TRUNC (SYSDATE) - 3, rcount, 0)) "today-3",
            SUM (DECODE (itime, TRUNC (SYSDATE) - 4, rcount, 0)) "today-4",
            SUM (DECODE (itime, TRUNC (SYSDATE) - 5, rcount, 0)) "today-5",
            SUM (DECODE (itime, TRUNC (SYSDATE) - 6, rcount, 0)) "today-6",
            SUM (DECODE (itime, TRUNC (SYSDATE) - 7, rcount, 0)) "today-7"
       FROM (SELECT   TYPE, TRUNC (itime) itime, COUNT (1) cnt, sum(actual_dts_rec) rcount
                 FROM v_all_adminer_job
                WHERE itime > TRUNC (SYSDATE) - 7
             GROUP BY TYPE, TRUNC (itime))
   GROUP BY TYPE
/

-- Grants for View
GRANT SELECT ON v_adminer_weekly_stat TO public
/

-- End of DDL Script for View ADR_DEF.V_ADMINER_WEEKLY_STAT

-- Start of DDL Script for View ADR_DEF.V_ADR_USERS
-- Generated 25-Feb-2010 16:38:55 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_adr_users (
   username )
AS
select username
 From all_users where username like 'ADR_%' and username not in ('ADR_DEF','ADR_MIG')
/

-- Grants for View
GRANT SELECT ON v_adr_users TO public
/

-- End of DDL Script for View ADR_DEF.V_ADR_USERS

-- Start of DDL Script for View ADR_DEF.V_ALL_AD_INSTANCES
-- Generated 25-Feb-2010 16:39:03 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_all_ad_instances (
   fetch_id,
   itime,
   ad_id,
   result_id,
   delivery_type,
   targeting,
   patrn_id,
   primary_target_domain,
   technology_id,
   ad_platform_id,
   original_location,
   final_location,
   original_target_url,
   country_code_id,
   job_id,
   md5,
   click_flag )
AS
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_TW.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_US.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_JP.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_OZ.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_BR.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_EU.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_KR.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_IN.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_CN.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_ZA.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_MB.ad_instances union all
select "FETCH_ID","ITIME","AD_ID","RESULT_ID","DELIVERY_TYPE","TARGETING","PATRN_ID","PRIMARY_TARGET_DOMAIN","TECHNOLOGY_ID","AD_PLATFORM_ID","ORIGINAL_LOCATION","FINAL_LOCATION","ORIGINAL_TARGET_URL","COUNTRY_CODE_ID","JOB_ID","MD5","CLICK_FLAG" from ADR_CA.ad_instances
/

-- Grants for View
GRANT SELECT ON v_all_ad_instances TO public
/

-- End of DDL Script for View ADR_DEF.V_ALL_AD_INSTANCES

-- Start of DDL Script for View ADR_DEF.V_ALL_ADMINER_JOB
-- Generated 25-Feb-2010 16:39:11 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_all_adminer_job (
   owner,
   id,
   type,
   itime,
   filename,
   status,
   row_count,
   actual_dts_rec,
   rec_inserted )
AS
SELECT 'ADR_EU' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_eu.adminer_job a
   UNION ALL
   SELECT 'ADR_CN' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_cn.adminer_job a
   UNION ALL
   SELECT 'ADR_BR' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_br.adminer_job a
   UNION ALL
   SELECT 'ADR_ZA' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_za.adminer_job a
   UNION ALL
   SELECT 'ADR_TW' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_tw.adminer_job a
   UNION ALL
   SELECT 'ADR_JP' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_jp.adminer_job a
   UNION ALL
   SELECT 'ADR_IN' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_in.adminer_job a
   UNION ALL
   SELECT 'ADR_OZ' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_oz.adminer_job a
   UNION ALL
   SELECT 'ADR_US' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_us.adminer_job a
   UNION ALL
   SELECT 'ADR_KR' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_kr.adminer_job a
   UNION ALL
   SELECT 'ADR_MB' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_mb.adminer_job a
   UNION ALL
   SELECT 'ADR_CA' owner, a."ID",a."TYPE",a."ITIME",a."FILENAME",a."STATUS",a."ROW_COUNT",a."ACTUAL_DTS_REC",a."REC_INSERTED"
     FROM adr_ca.adminer_job a
/

-- Grants for View
GRANT SELECT ON v_all_adminer_job TO public
/

-- End of DDL Script for View ADR_DEF.V_ALL_ADMINER_JOB

-- Start of DDL Script for View ADR_DEF.V_ALL_PROBE_RESULT
-- Generated 25-Feb-2010 16:39:19 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_all_probe_result (
   fetch_id,
   itime,
   country_code_id,
   map_id,
   location_id,
   proxy_id,
   site_id,
   top_level_site_id,
   scale,
   result_id,
   ads_rec,
   ads_unrec,
   reload_duration,
   num_http_error,
   num_javascrpt_error,
   num_http_request,
   num_bytes,
   num_request_timeout,
   sectres_actual_url_id,
   user_profile_id,
   job_id,
   bro_id,
   host_id )
AS
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_TW.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_US.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_JP.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_OZ.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_BR.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_EU.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_KR.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_IN.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_CN.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_ZA.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_MB.probe_result union all
select "FETCH_ID","ITIME","COUNTRY_CODE_ID","MAP_ID","LOCATION_ID","PROXY_ID","SITE_ID","TOP_LEVEL_SITE_ID","SCALE","RESULT_ID","ADS_REC","ADS_UNREC","RELOAD_DURATION","NUM_HTTP_ERROR","NUM_JAVASCRPT_ERROR","NUM_HTTP_REQUEST","NUM_BYTES","NUM_REQUEST_TIMEOUT","SECTRES_ACTUAL_URL_ID","USER_PROFILE_ID","JOB_ID","BRO_ID","HOST_ID" from ADR_CA.probe_result
/

-- Grants for View
GRANT SELECT ON v_all_probe_result TO public
/

-- End of DDL Script for View ADR_DEF.V_ALL_PROBE_RESULT

-- Start of DDL Script for View ADR_DEF.V_PROBE_MAP
-- Generated 25-Feb-2010 16:39:27 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_probe_map (
   id,
   active,
   itime,
   period_type,
   period,
   probe_allocation,
   area_number,
   source_map_id,
   type,
   country_code )
AS
SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'EU' AS country_code
     FROM adr_eu.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'OZ' AS country_code
     FROM adr_oz.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'JP' AS country_code
     FROM adr_jp.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'CN' AS country_code
     FROM adr_cn.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'US' AS country_code
     FROM adr_us.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'TW' AS country_code
     FROM adr_tw.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'ZA' AS country_code
     FROM adr_za.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'BR' AS country_code
     FROM adr_br.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'KR' AS country_code
     FROM adr_kr.probe_map a
   UNION ALL
   SELECT a."ID",a."ACTIVE",a."ITIME",a."PERIOD_TYPE",a."PERIOD",a."PROBE_ALLOCATION",a."AREA_NUMBER",a."SOURCE_MAP_ID",a."TYPE", 'IN' AS country_code
     FROM adr_in.probe_map a
/

-- Grants for View
GRANT DELETE ON v_probe_map TO public
/
GRANT INSERT ON v_probe_map TO public
/
GRANT SELECT ON v_probe_map TO public
/
GRANT UPDATE ON v_probe_map TO public
/
GRANT REFERENCES ON v_probe_map TO public
/
GRANT ON COMMIT REFRESH ON v_probe_map TO public
/
GRANT QUERY REWRITE ON v_probe_map TO public
/
GRANT DEBUG ON v_probe_map TO public
/
GRANT FLASHBACK ON v_probe_map TO public
/
GRANT MERGE VIEW ON v_probe_map TO public
/

-- End of DDL Script for View ADR_DEF.V_PROBE_MAP

-- Start of DDL Script for View ADR_DEF.V_PROBE_RESULT_EXT
-- Generated 25-Feb-2010 16:39:34 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_probe_result_ext (
   fetch_id,
   itime,
   country_code_id,
   map_id,
   location_id,
   proxy_id,
   site_id,
   top_level_site_id,
   scale,
   result_id,
   ads_rec,
   ads_unrec,
   reload_duration,
   num_http_error,
   num_javascrpt_error,
   num_http_request,
   num_bytes,
   num_request_timeout,
   user_profile_id,
   sectres_actual_url,
   bro_id,
   host_id,
   clicks )
AS
SELECT fetch_id, TO_DATE (itime, 'dd-mon-yyyy hh24:mi:ss') itime,
          country_code_id, map_id, location_id, proxy_id, site_id,
          top_level_site_id, scale, result_id, ads_rec, ads_unrec,
          reload_duration, num_http_error, num_javascrpt_error,
          num_http_request, num_bytes, num_request_timeout, user_profile_id,
          sectres_actual_url, bro_id, b.host_id,clicks
     FROM ADR_def.probe_result_ext a,
          adr_def.browser_host b
    WHERE a.host_name = b.host_name(+)
/


-- End of DDL Script for View ADR_DEF.V_PROBE_RESULT_EXT

-- Start of DDL Script for View ADR_DEF.V_PROXY_STRATEGY
-- Generated 25-Feb-2010 16:39:42 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_proxy_strategy (
   id,
   country_id )
AS
SELECT   NVL (MAX (e.ID), 0) ID, country_id
       FROM proxy_strategy e
      WHERE e.status = 1
   GROUP BY country_id
/

-- Grants for View
GRANT SELECT ON v_proxy_strategy TO public
/

-- End of DDL Script for View ADR_DEF.V_PROXY_STRATEGY

-- Start of DDL Script for View ADR_DEF.V_PROXY_USAGE
-- Generated 25-Feb-2010 16:39:50 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_proxy_usage (
   country_name,
   country_code_id,
   proxy_id,
   proxy_host,
   proxy_port,
   probe_count,
   proxy_usage )
AS
SELECT   country_name, country_code_id, proxy_id, proxy_host, proxy_port,
            cnt probe_count,
            ROUND (cnt * 100 / SUM (cnt) OVER (PARTITION BY country_code_id),
                   2
                  ) proxy_usage
       FROM (SELECT country_name, country_code_id, cnt, x.proxy_id,
                    proxy_host, proxy_port
               FROM (SELECT          --+aprallel(a,4)
                            DISTINCT country_code_id, proxy_id, COUNT (1) cnt
                                FROM v_all_probe_result a
                               WHERE itime > TRUNC (SYSDATE)
                            GROUP BY country_code_id, proxy_id) x,
                    proxy y,
                    country z
              WHERE y.proxy_id = x.proxy_id
                AND x.country_code_id = z.country_id)
   ORDER BY country_name
/

-- Grants for View
GRANT SELECT ON v_proxy_usage TO public
/

-- End of DDL Script for View ADR_DEF.V_PROXY_USAGE

-- Start of DDL Script for View ADR_DEF.V_RANDOM_NAVIGATION_ACCOUNT
-- Generated 25-Feb-2010 16:39:58 from ADR_DEF@prdcoll

CREATE OR REPLACE VIEW v_random_navigation_account (
   id,
   active,
   site_id,
   username,
   password,
   country_id )
AS
SELECT ID, active, site_id, username, PASSWORD, country_id
     FROM (SELECT b.*,
                  ROW_NUMBER () OVER (PARTITION BY site_id ORDER BY DBMS_RANDOM.VALUE)
                                                                          rec
             FROM adr_def.navigation_account b
            WHERE active = 1)
    WHERE rec <= 1
/


-- End of DDL Script for View ADR_DEF.V_RANDOM_NAVIGATION_ACCOUNT


-- Start of DDL Script for View ADR_DEF.V_AD_EXT
-- Generated 3-May-2010 20:17:36 from ADR_DEF@PRDCOLL

CREATE OR REPLACE VIEW v_ad_ext (
   itime,
   ad_status_id,
   ad_width,
   ad_height,
   ad_size,
   dest_loc_url,
   md5,
   property_id,
   ad_directory,
   ad_name,
   ad_target_redirection_type,
   platform_id,
   technology_id,
   md5_meter,
   debug_flag )
AS
SELECT  TO_DATE (itime, 'dd-mon-yyyy hh24:mi:ss') itime,
        get_default_ad_status(technology_id, trim(dest_loc_url)) ad_status_id,
        ad_width, ad_height, ad_size, TRIM(replace(dest_loc_url,CHR(0),'')) dest_loc_url, md5, property_id, ad_directory,
        TRIM(ad_name) ad_name, ad_target_redirection_type, platform_id, technology_id, REPLACE (md5_meter, CHR (13), '') md5_meter,DEBUG_FLAG
     FROM ADR_DEF.ad_ext
/


-- End of DDL Script for View ADR_DEF.V_AD_EXT




