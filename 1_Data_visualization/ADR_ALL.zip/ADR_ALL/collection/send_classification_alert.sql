<%

_run.emailTo='Jagdish.Patil@Nielsen.com;Shishir.Sathe.ap@Nielsen.com;Tony.Lam@Nielsen.com;Mark.Sacman@Nielsen.com;Prashant.Tripathi.ap@Nielsen.com'
_run.emailSubject = 'Classification: Statistics for AD'

%>;

define message=_array

define message= ADs of last 7 days without a record in AD_COUNTRY
         
COL _rowset noprint message

SELECT COUNT (1) ad_not_ad_country
  FROM ad
 WHERE itime > SYSDATE - 7
   AND itime < SYSDATE - 2 / 24
   AND NOT EXISTS (SELECT 1
                     FROM ad_country
                    WHERE ad_id = ID);

define message= ADs older than 7 days and still in status 1
         
COL _rowset noprint message

SELECT COUNT (1) ad_status_1
  FROM ad
 WHERE itime < SYSDATE - 7 AND itime > '01-JAN-2010' AND ad_status_id = 1;


define message= ADs per Country older than 7 days,ad status 1 and ad_country status 0

COL _rowset noprint message

select (select country_name from country c where c.country_id=a.country_id)country, country_id
,count(1) count 
from ad_country a
where ad_id in 
(
select id from ad where itime < sysdate - 7
and ad_status_id =1
and itime > '01-Jan-2010' 
)
and status=0
group by country_id
order by country
;


define message= ADs for which Campaign were not created within 14 days  
         
COL _rowset noprint message

SELECT COUNT (1) ads_no_campaign
  FROM ad
 WHERE itime >= '01-Feb-2010' AND itime < (SYSDATE - 14)
   AND ad_status_id = 2
   AND TRIM (cam_id) IS NULL
   AND TRIM (dest_loc_url) IS NOT NULL
   AND NVL (technology_id, -1) <> 5;

define message= Campaigns older than 7 days and with status Incomplete (Unclassified)  
         
COL _rowset noprint message

SELECT COUNT (1) unclassified_campaigns
  FROM campaign
 WHERE itime BETWEEN '01-Feb-2010' AND (SYSDATE - 7) AND campaign_status = 1;

define message= Number of campaigns without a campaign_country record  
         
COL _rowset noprint message
SELECT COUNT (1) cam_without_cam_country
  FROM campaign c, ad_country ad, ad a
 WHERE c.itime > SYSDATE - 14
--   AND c.itime < SYSDATE - 2 / 24
   AND a.cam_id = c.ID
   AND ad.ad_id = a.ID
   AND ad.status > 1
   AND NOT EXISTS (
            SELECT 1
              FROM campaign_country cc
             WHERE ABS (cc.campaign_id) = c.ID
                   AND cc.country_id = ad.country_id);


define message= Advertisers with Broken Hierarchy
         
COL _rowset noprint message
SELECT ID advr_id, NAME, (SELECT NAME
                            FROM advertisable_type
                           WHERE ID = TYPE) TYPE,
       (SELECT status
          FROM advertisable_status
         WHERE ID = advertisable_status) status, PARENT
  FROM advertisable
 WHERE ID IN (SELECT advr_id
                FROM get_advertiser_hier
               WHERE advr_type IN (121, 141, 201) AND company IS NULL)
   AND advertisable_status > 0;


email message;

