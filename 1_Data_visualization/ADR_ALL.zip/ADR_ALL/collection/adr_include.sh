## added on 02-Mar by shishir
usage()
{
  echo " "
  echo "ADR back-end process wrapper."
  echo "Usage: $0 [-d date] [-e emailto] [-j job name] [...process parameters...]"
  echo " "
  exit 1
}

function log {
echo "`date '+%Y-%m-%d %H.%M.%S'`.$$ : $1: $name: $2" >> $logfile

if test $1 -le 3
then
sed "1,/$start_msg/d" $logfile | mail -s "ERROR:$name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}

function get_pw {
cat .pw |tr [:lower:] [:upper:] |awk '{if ($1==dbusr && $3==dbname) print $2}' dbusr="`echo $1 | tr [:lower:] [:upper:]`" dbname="`echo $2 | tr [:lower:] [:upper:]`"
}

cd `dirname $0`
name=`basename $0`
. ~adrusr/.profile
. /adr/core/.email_list

mypid=$$

if test -z "$logfile"
then
logfile="$ADRLOGFOLDER/$name.log"
fi

while getopts ":j:d:e:" opt; do
  case $opt in
    j  ) run_cmjobname="`echo $OPTARG| sed 's/^ *//'`"  ;;
    d  ) run_date="`echo $OPTARG| sed 's/^ *//'`"       ;;
    e  ) error_email="`echo $OPTARG| sed 's/^ *//'`"      ;;
    \? ) usage ;;
  esac
done

shift $(($OPTIND - 1))

export run_cmjobname=$run_cmjobname
export run_date=$run_date


if test -z "$error_email"
then

error_email="$EMAIL_ADR_ERROR"
fi

export error_email=$error_email
