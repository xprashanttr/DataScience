#!/bin/bash
. ~adrusr/.profile

export TNS_ADMIN=/adr/core

#sqlsh -d `date +\%y\%m\%d` -u adr_def@prdcoll -s d -j prdcoll_loader_stats -c def -o /adr/core/cfg.ora/phoenix.cfg @pr_prd_loader_alert.sql

## subject will have WARNING if pending files > 400
sqlsh -d `date +\%y\%m\%d` -u adr_def@prdcoll -s d -j prdcoll_loader_stats -c def -o /adr/core/cfg.ora/phoenix.cfg @pr_prd_loader_alert2.sql
