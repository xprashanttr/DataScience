#!/bin/bash
cd `dirname $0`
name=`basename $0`
basedir=`pwd` #02/18

. ~adrusr/.profile
. .email_list
. $basedir/adr_include.sh #02/18

### overwriting the error email list for DTS jobs. List now includes adminer team also.
error_email="$EMAIL_ADR_ERROR $EMAIL_ADMINER_SUPPORT"

logfile="$ADRLOGFOLDER/$name.log"
mypid=$$

function log {
echo "`date '+%Y-%m-%d %H.%M.%S'`.$$ : $1: $name: $2" >> $logfile

if test $1 -le 3
then
#02/18 job name added
sed "1,/$start_msg/d" $logfile | mail -s "ERROR:$job_name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}


if test -z "$run_cmjobname"
then
job_name=$name
else
job_name=$run_cmjobname
fi

#echo ""
#echo $job_name
#echo $run_date
#echo $logfile
#echo $error_email
#echo ""

start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"
echo $start_msg >> $logfile

oldpid="`ls -1 /tmp/$name.* | awk -F'.' '{print $3}'`"

if test -n "`ps -aef |grep $name | grep $oldpid`"
then
log 5 "$name instance ( pid=$oldpid ) is already running. exiting..."
exit;
else
rm -f /tmp/$name.*
touch /tmp/$name.$$
fi

cclist="ca"

##LOAD PROBE_RESULT & AD_INSTANCES FILES
for cc in $cclist
do
$basedir/run_orasql.sh -j $run_cmjobname -d $run_date $cc prd "exec ADR_DTS_LOAD.LOAD('$cc','probe_result')"
#echo "probe_result -$cc done"
done

log 5 "end $0 $*"
