#!/bin/bash
. ~adrusr/.profile

export TNS_ADMIN=/adr/core
db=prdtools


sqlsh -d `date +\%y\%m\%d` -u adrbo@prdtools -s d -j classification_issue -c adrbo -o /adr/core/cfg.ora/phoenix.cfg @send_classification_alert.sql

