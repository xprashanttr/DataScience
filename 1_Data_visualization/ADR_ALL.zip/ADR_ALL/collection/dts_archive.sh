#!/bin/bash
cd `dirname $0`
name=`basename $0`
basedir=`pwd` #02/18

. ~adrusr/.profile
. .email_list
. $basedir/adr_include.sh #02/18


logfile="$ADRLOGFOLDER/$name.log"
mypid=$$

DTS_FOLDER="/DTS/AdMiner"
ARCHIVE_FOLDER="/DTS/archive"
#ARCHIVE_NAME="$ARCHIVE_FOLDER/`date +'%Y%m%d' -d '-10 days'`.tar"
ARCHIVE_STEM="`date +'%Y%m%d' -d '-9 days'`"
touch -m -t `date +'%Y%m%d0000' -d "-8 days"` /tmp/today_7.txt
touch -m -t `date +'%Y%m%d0000' -d "-20 days"` /tmp/today_20.txt

cd $DTS_FOLDER

start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"
echo $start_msg >> $logfile

function log {
echo "`date '+%Y-%m-%d %H.%M.%S'`: $1: $name: $2" >> $logfile

if test $1 -le 3
then
sed "1,/$start_msg/d" $logfile | mail -s "ERROR:$job_name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}

if test -z "$run_cmjobname"
then
job_name=$name
else
job_name=$run_cmjobname
fi

#echo ""
#echo $job_name
#echo $run_date
#echo $logfile
#echo $error_email
#echo ""


log 5 "start $0 $*"

if test -n "$1"
then
#overwrite error email list
error_email="$1"
else
error_email="$EMAIL_ADR_ERROR"
fi

#echo "error_email=$error_email"

fcnt=0;
i=0;
ARCHIVE_NAME="$ARCHIVE_FOLDER/$ARCHIVE_STEM.$fcnt.tar"

find . -type f -name '*.*' ! -newer /tmp/today_7.txt | while read line
do
i=$(($i+1))
if test $(($i % 1000)) -eq 0
then
fcnt=$(($fcnt+1))
ARCHIVE_NAME="$ARCHIVE_FOLDER/$ARCHIVE_STEM.$fcnt.tar"
fi

ls -l $line >> $ARCHIVE_NAME.txt
tar --remove-files -rf $ARCHIVE_NAME $line
done

#gzip tar file
log 5 "zip $ARCHIVE_STEM files"
gzip -f "$ARCHIVE_FOLDER/$ARCHIVE_STEM".* 

#delete files older than 20 days
cd $ARCHIVE_FOLDER
find . -type f -name '*.gz' ! -newer /tmp/today_20.txt | while read line
do
rm -f $line
done
log 5 "end $0 $*"

