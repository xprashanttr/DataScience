#!/bin/bash
#############
# delete older than 30 days banner cache entries
# banner cache folder is /ADS_Crawling/bannerCache2
# banner cache is written and used by AdMiner to decide whether to write banner file
#############
. /adr/core/adr_include.sh

BANNERCACHE_FOLDER="/ADS_Crawling/bannerCache2"
start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"
echo $start_msg >> $logfile

log 5 "start $0 $*"

mode=$1
if test -z "$mode"
then
log 3 "missing input parameter"
fi

cd $BANNERCACHE_FOLDER
touch -m -t `date +'%Y%m%d0000' -d "-30 days"` /tmp/today_30.txt

##if mode=file then delete bannercache files
if test $mode = "file"
then
echo "in file mode..........."
ls -1 | grep "^7$" | while read bdir
do
cd $BANNERCACHE_FOLDER/$bdir 
find . -type f -name '*.obj' ! -newer /tmp/today_30.txt | while read line
do
ls -l $line
rm -f $line
done
done
fi

##if mode=folder then delete empty folder
if test $mode = "folder"
then
#find -depth -type d -empty -exec rmdir {} \;
find -depth -type d -empty | while read line
do
rmdir -v $line
done

fi

log 5 "end $0 $*"

