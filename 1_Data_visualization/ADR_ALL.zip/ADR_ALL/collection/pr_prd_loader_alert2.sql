<%

_run.emailTo='Ankur.Tandon.ap@nielsen.com;Surendradutt.Prajapati.ap@nielsen.com;Akshaya.vengurlekar.ap@nielsen.com;Swati.Agarwal.ap@nielsen.com;Shuchi.Agarwal.ap@nielsen.com;Prashant.Tripathi.ap@nielsen.com;'

%>;

define message=_array

define message= PRDCOLL: Reported and loaded files in last one hour for All Platforms
         
COL _rowset noprint message

SELECT   a.owner, a.TYPE, NVL (a.files_reported_1hr, 0) files_reported_1hr,
         NVL (b.files_loaded_1hr, 0) files_loaded_1hr,
         NVL (c.total_unloaded_files, 0) total_unloaded_files
    FROM (SELECT NVL (owner, 'TOTAL_FILES') owner,
                 NVL (TYPE, 'TOTAL_FILES') TYPE, files_reported_1hr
            FROM (SELECT   owner, TYPE, COUNT (1) files_reported_1hr
                      FROM v_all_adminer_job
                     WHERE itime > SYSDATE - 1 / 24
                  GROUP BY ROLLUP (owner, TYPE)
                  ORDER BY owner, TYPE)) a,
         (SELECT NVL (owner, 'TOTAL_FILES') owner,
                 NVL (TYPE, 'TOTAL_FILES') TYPE, files_loaded_1hr
            FROM (SELECT   owner, TYPE, COUNT (1) files_loaded_1hr
                      FROM (SELECT 'ADR_EU' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_eu.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_CN' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_cn.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_BR' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_br.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_ZA' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_za.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_TW' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_tw.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_JP' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_jp.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_IN' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_in.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_OZ' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_oz.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_US' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_us.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_KR' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_kr.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_MB' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_mb.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                            UNION ALL
                            SELECT 'ADR_CA' owner, a.ID, a.TYPE, a.itime,
                                   a.filename, a.status, a.row_count,
                                   a.actual_dts_rec, a.rec_inserted,
                                   a.upload_time
                              FROM adr_ca.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1)
                     --WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                  GROUP BY ROLLUP (owner, TYPE)
                  ORDER BY owner, TYPE)) b,
         (SELECT NVL (owner, 'TOTAL_FILES') owner,
                 NVL (TYPE, 'TOTAL_FILES') TYPE, total_unloaded_files
            FROM (SELECT   owner, TYPE, COUNT (1) total_unloaded_files
                      FROM v_all_adminer_job
                     WHERE status = 0
                  GROUP BY ROLLUP (owner, TYPE)
                  ORDER BY owner, TYPE)) c
   WHERE a.owner = b.owner(+) AND a.TYPE = b.TYPE(+) AND a.owner = c.owner(+)
         AND a.TYPE = c.TYPE(+)
ORDER BY a.owner, a.TYPE;

COL c_emailSubject print new_val emailSubject
SELECT CASE
          WHEN (total_unloaded_files > 400)
             THEN 'WARNING PRDCOLL: Too Much Pending Files for Loader'
          ELSE 'PRDCOLL: Pending Files for All Platforms'
       END c_emailsubject
  FROM (SELECT   a.owner, a.TYPE,
                 NVL (a.files_reported_1hr, 0) files_reported_1hr,
                 NVL (b.files_loaded_1hr, 0) files_loaded_1hr,
                 NVL (c.total_unloaded_files, 0) total_unloaded_files
            FROM (SELECT NVL (owner, 'TOTAL_FILES') owner,
                         NVL (TYPE, 'TOTAL_FILES') TYPE, files_reported_1hr
                    FROM (SELECT   owner, TYPE, COUNT (1) files_reported_1hr
                              FROM v_all_adminer_job
                             WHERE itime > SYSDATE - 1 / 24
                          GROUP BY ROLLUP (owner, TYPE)
                          ORDER BY owner, TYPE)) a,
                 (SELECT NVL (owner, 'TOTAL_FILES') owner,
                         NVL (TYPE, 'TOTAL_FILES') TYPE, files_loaded_1hr
                    FROM (SELECT   owner, TYPE, COUNT (1) files_loaded_1hr
                              FROM (SELECT 'ADR_EU' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_eu.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_CN' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_cn.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_BR' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_br.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_ZA' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_za.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_TW' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_tw.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_JP' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_jp.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_IN' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_in.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_OZ' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_oz.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_US' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_us.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_KR' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_kr.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_MB' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_mb.adminer_job a WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                                    UNION ALL
                                    SELECT 'ADR_CA' owner, a.ID, a.TYPE,
                                           a.itime, a.filename, a.status,
                                           a.row_count, a.actual_dts_rec,
                                           a.rec_inserted, a.upload_time
                                      FROM adr_ca.adminer_job a  WHERE upload_time > SYSDATE - 1 / 24 AND status = 1)
                             --WHERE upload_time > SYSDATE - 1 / 24 AND status = 1
                          GROUP BY ROLLUP (owner, TYPE)
                          ORDER BY owner, TYPE)) b,
                 (SELECT NVL (owner, 'TOTAL_FILES') owner,
                         NVL (TYPE, 'TOTAL_FILES') TYPE, total_unloaded_files
                    FROM (SELECT   owner, TYPE, COUNT
                                                     (1) total_unloaded_files
                              FROM v_all_adminer_job
                             WHERE status = 0
                          GROUP BY ROLLUP (owner, TYPE)
                          ORDER BY owner, TYPE)) c
           WHERE a.owner = b.owner(+)
             AND a.TYPE = b.TYPE(+)
             AND a.owner = c.owner(+)
             AND a.TYPE = c.TYPE(+)
        ORDER BY a.owner, a.TYPE) 
 WHERE owner = 'TOTAL_FILES';


email message;
