set feedback off;
set verify off;
set heading off;
set linesize 1000
set trimspool on
set pagesize 0
set termout off;
COL c_dbname noprint new_value v_dbname
COL c_date noprint new_value v_date

select name c_dbname from v$database;
select to_char(sysdate-1,'YYYYMMDD') c_date from dual;

spool /internet/apps/apache/htdocs/classification_stat.&v_dbname..&v_date..txt 

select txt from (
select -1 id, '<tr class="italic" ><td colspan="5" align="right" border="0">last updated: '||to_char(sysdate,'dd-Mon-yyyy hh24:mi:ss')||' eastern time</td></tr>' txt from dual
union all
select 0 id, '<tr class="head"><td>username</td><td>ad</td><td>campaign</td><td>advertiser</td><td>total</td></tr>' txt from dual
union all
select 1, '<tr class="'||decode(mod(rownum,2),0,'yellow','white')||'"></td><td>'||username||'</td><td>'||ad_count||'</td><td>'||cam_count||'</td><td>'||advr_count||'</td><td>'||total||'</td></tr>'
from (
SELECT  username, SUM (DECODE (type, 'ad', cnt, 0)) ad_count,
         SUM (DECODE (type, 'cam', cnt, 0)) cam_count,
         SUM (DECODE (type, 'advr', cnt, 0)) advr_count, SUM (cnt) total
    FROM ( SELECT   --+index(a,in_audev_time )
                   username, 'ad' TYPE, COUNT (DISTINCT parameter_1) cnt
              FROM audited_event a
             WHERE TIME BETWEEN TRUNC (SYSDATE - 1) AND TRUNC (SYSDATE)
               AND TYPE = 19
               AND username <> 'ADRBO'
          GROUP BY username
          UNION ALL
          SELECT   --+indeX(a,in_audev_time )
                   username, 'cam' TYPE, COUNT (DISTINCT parameter_1) cnt
              FROM audited_event a
             WHERE TIME BETWEEN TRUNC (SYSDATE - 1) AND TRUNC (SYSDATE)
               AND TYPE = 28
               AND username <> 'ADRBO'
          GROUP BY username
          UNION ALL
          SELECT   --+indeX(a,in_audev_time )
                   username, 'advr' TYPE, COUNT (DISTINCT parameter_1) cnt
              FROM audited_event a
             WHERE TIME BETWEEN TRUNC (SYSDATE - 1) AND TRUNC (SYSDATE)
               AND TYPE = 48
               AND username <> 'ADRBO'
          GROUP BY username
          )
GROUP BY  username ORDER BY username
) x 
union all
  SELECT   --+indeX(a,in_audev_time )
                   3 id, '<tr class="blue" ><td>total</td><td>'||
                   count( distinct decode(type, 19,parameter_1,null)) ||'</td><td>'||
                   count( distinct decode(type, 28,parameter_1,null))||'</td><td>'||
                   count( distinct decode(type, 48,parameter_1,null)) ||'</td><td>'||
                   count(distinct type||'|'||parameter_1) ||'</td></tr>'
              FROM audited_event a
             WHERE TIME BETWEEN TRUNC (SYSDATE - 1) AND TRUNC (SYSDATE)
               AND TYPE in(19,28, 48 )
               AND username <> 'ADRBO'
)
--order by id
;

