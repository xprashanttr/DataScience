#!/bin/bash
################
#sync banners daily from BE filer to UI filer
#daily job copies files
#weekly job syncs UI banners folder with BE banners folder
###############
. /adr/core/adr_include.sh

SRC_BANNER_HOME="/ADS_Crawling/banners"
TARGET_BANNER_HOME="/Ads_Crawling/banners"
REMOTE_HOST="ntrtusr@tparhenrtq001.nielsen.com"
s=-3
e=1

mode=$1

if test $mode = "weekly"
then
s=-10
e=1
fi

start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"

log 5 "start $0 $*"

cd $SRC_BANNER_HOME

cclist="us mobile eu oz jp kr br in cn za tw ca"
for cc in $cclist 
do
for i in `seq $s $e` 
do
dirday="`date -d \"$i days\" '+%y/%m/%d'`"
SRC_DIR="$SRC_BANNER_HOME/$cc/$dirday"
TARGET_DIR="$TARGET_BANNER_HOME/$cc/$dirday"

if test -d "$SRC_DIR"
then

#log 5 "check $TARGET_DIR on remote host"
ssh $REMOTE_HOST "ls -d $TARGET_DIR"
status=$?

if test $status -eq 0
then
#log 5 "run rsync"
#echo "rsync --exclude '*_SPONLNK_*' -avz $SRC_DIR/ $REMOTE_HOST:$TARGET_DIR"
rsync --delete-after --exclude '*_SPONLNK_*' -az "$SRC_DIR/" "$REMOTE_HOST:$TARGET_DIR"
log 5 "$SRC_DIR sync done"
else
log 5 "create dir $TARGET_DIR on remote host"
ssh $REMOTE_HOST "mkdir -p $TARGET_DIR"
status=$?
if test $status -eq 0
then
#log 5 "dir created..run rsync"
#echo "rsync --exclude '*_SPONLNK_*' -avz $SRC_DIR/ $REMOTE_HOST:$TARGET_DIR"
rsync --delete-after --exclude '*_SPONLNK_*' -az "$SRC_DIR/" "$REMOTE_HOST:$TARGET_DIR"
log 5 "$SRC_DIR sync done"
else
log 5 "stop..."
fi

fi

fi ##end if $SRC_DIR

done

done
log 5 "end $0 $*"

