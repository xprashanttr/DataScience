whenever sqlerror exit 1
col c_filename noprint new_value v_filename
set feedback off;
set verify off;
set heading off;
set termout off;`

DELETE FROM deleted_expired_ads;


INSERT INTO deleted_expired_ads
            (ID, technology_id, md5)
   SELECT --+ordered index(b,pk_ad_id)
          b.ID, b.technology_id, b.md5
     FROM ad_class a, ad b
    WHERE a.last_updated BETWEEN TO_DATE ('&1', 'YYYYMMDD') - 1
                             AND TO_DATE ('&1', 'YYYYMMDD')
      AND a.ad_expired = 1
      AND b.ID = a.ID
      AND b.ad_expired <> 1
      AND ROWNUM < 5000;

set feedback off;
set verify off;
set heading off;
set termout off;`
set linesize 1000
set trimspool on
set pagesize 0
!rm -f dbanner_cahche.sh
spool dbanner_cahche.sh
select 'rm -f /ADS_Crawling/bannerCache2/'||technology_id||'/'||substr(md5,1,4)||'/'||substr(md5,5,4)||'/'||md5||'.obj' 
from   deleted_expired_ads;    
spool off;

!chmod 744 dbanner_cahche.sh
!./dbanner_cahche.sh  >> $ADRLOGFOLDER/dbanner_cahche.sh.log
!cat dbanner_cahche.sh >> &1..log

!gzip -f &1..log
!mv &1..log.gz $ADRLOGFOLDER/&1..log.gz

UPDATE --+index(ad,pk_ad_id)
       ad
   SET ad_expired = 1
 WHERE ID IN (SELECT ID
                FROM deleted_expired_ads) AND ad_expired <> 1
;

COMMIT;
SELECT decode(count(1),1,'mark_ad_expiry.sql','null.sql') c_filename
  FROM ad_class a
 WHERE a.last_updated BETWEEN TO_DATE ('&1', 'YYYYMMDD') - 1
                          AND TO_DATE ('&1', 'YYYYMMDD')
   AND a.ad_expired = 1
   AND EXISTS (SELECT 1
                 FROM ad
                WHERE ID = a.ID AND ad_expired <> 1)
   AND ROWNUM < 2 
;

@&v_filename &1
