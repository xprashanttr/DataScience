#!/bin/bash
cd `dirname $0`
name=`basename $0`
basedir=`pwd` #02/18

. ~adrusr/.profile
. .email_list
. $basedir/adr_include.sh #02/18

logfile="$ADRLOGFOLDER/$name.log"
mypid=$$


function log {
echo "`date '+%Y-%m-%d %H.%M.%S'`.$$ : $1: $name: $2" >> $logfile

if test $1 -le 3
then
sed "1,/$start_msg/d" $logfile | mail -s "ERROR:$job_name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}

if test -z "$run_cmjobname"
then
job_name=$name
else
job_name=$run_cmjobname
fi

#echo ""
#echo $job_name
#echo $run_date
#echo $logfile
#echo $error_email
#echo ""

start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"
echo $start_msg >> $logfile

$basedir/run_orasql.sh -j $run_cmjobname -d $run_date def prd "@sync_recapture_ad_tools2collect.sql"
$basedir/run_orasql.sh -j $run_cmjobname -d $run_date bo prdtool "@sync_recapture_ad_collect2tools.sql"

log 5 "done $0 $*"

