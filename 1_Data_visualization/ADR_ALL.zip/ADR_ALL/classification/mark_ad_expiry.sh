#!/bin/bash
cd `dirname $0`
name=`basename $0`
basedir=`pwd`

. ~adrusr/.profile
. .email_list
. $basedir/adr_include.sh

logfile="$ADRLOGFOLDER/$name.log"
export TNS_ADMIN=/adr/core

start_msg="`date '+%Y.%m.%d.%H.%M.%S'`.$$"
echo $start_msg >> $logfile

function log {
echo "`date '+%Y-%m-%d %H.%M.%S'`: $1: $name: $2" >> $logfile

if test $1 -le 3
then
sed "1,/$start_msg/d" $logfile | mail -s "ERROR:$job_name failed on `hostname`.Please see $logfile for more details" "$error_email"
exit 1
fi

}

if test -z "$run_cmjobname"
then
job_name=$name
else
job_name=$run_cmjobname
fi

#echo ""
#echo $job_name
#echo $run_date
#echo $logfile
#echo $error_email
#echo ""


log 5 "Start $0 $*"

function get_pw {
cat .pw |tr [:lower:] [:upper:] |awk '{if ($1==dbusr && $3==dbname) print $2}' dbusr="`echo $1 | tr [:lower:] [:upper:]`" dbname="`echo $2 | tr [:lower:] [:upper:]`"
}


case $2 in
'prd') dbname="prdcoll"
       ;;
'stg') dbname="stgcoll"
       ;;
'dev') dbname="adrcoll"
      ;;
*) log 3 "ERROR:unknown environment"
     ;;
esac

case $1 in
'def')dbusr="adr_def"
     ;;
*) log 3 "ERROR:Incorrect user for this process"
     ;;
esac

dbpasswd="`get_pw $dbusr $dbname`"

if test -z "$dbpasswd"
then
log 3  "ERROR:passwd not known for $dbusr@$dbname contact database administrator"
fi


## ADDED BY PRASHANT ON 12-APR-2010: TO, FIRST: MARK CAMPAIGN_EXPIRY IN CLASSIFICATION
$basedir/run_orasql.sh -j ADR_MARK_CAM_EXPIRED -d `date '+\%y\%m\%d'` bo prdtool "exec xsync.mark_campaign_expired"



offset=$3

if test -z $3
then
offset=1
fi

echo "connecting to db $dbusr@$dbname"

log 5 "connecting to db $dbusr@$dbname"
log 5 "Process of banner cache cleanup and marking ads as expired Starts at `date`"

while [[ $offset -gt 0 ]]
do
day=`date '+%Y%m%d' -d "-$offset days"`
#day="20100304"
offset=`expr $offset - 1`
echo "date = $day"
echo "offset = $offset"
sqlplus -S $dbusr/$dbpasswd@$dbname << eof++ >> $logfile
@mark_ad_expiry.sql $day
exit 0;
eof++
done

log 5 "Process of banner cache cleanup and marking ads as expired Ends at `date`"


log 5 "End $0 $*"


