-- run this on adr_def@PRDCOLL
-- update issue_id to 1650 for ads marked for recapture in TOOLS
UPDATE ad
   SET issue_id = 1650
 WHERE ID IN (SELECT ID
                FROM ad_upd_for_collect);
--ad_upd_for_collect table exists on PRDTOOLS
DELETE FROM ad_upd_for_collect a
      WHERE EXISTS (SELECT 1
                      FROM ad
                     WHERE ID = a.ID AND issue_id = 1650);
COMMIT ;

