--run this on adrbo@PRDTOOL
-- update issue_id,width,height,ad_directory,ad_status_id,job_id for recaptured ads
BEGIN
   FOR i IN (SELECT b.*
               FROM ad_upd_for_tools a, ad@to_prdcoll b
              WHERE b.ID = a.ID )
   LOOP
      UPDATE --+(ad,pk_ad)
          ad
         SET ad_width = i.ad_width,
             ad_height = i.ad_height,
             ad_directory = i.ad_directory,
             dest_loc_url = i.dest_loc_url,
             issue_id = NULL,
             ad_status_id=1,
             last_updated = SYSDATE,
	      job_id = i.job_id
       WHERE ID = i.ID and ad_status_id <= 0;

-- added on 29-May 

	UPDATE ad_country
	   SET status = 1,
	       issue_id = NULL
	 WHERE ad_id = i.ID 
	 AND issue_id = 1650
	;

   END LOOP;

   COMMIT;
END;
/
-- ad_upd_for_tools table exists on PRDCOLL
DELETE FROM ad_upd_for_tools a
      WHERE EXISTS (SELECT 1
                     FROM ad
                    WHERE ID = a.ID AND NVL (issue_id, 0) <> 1650);
COMMIT ;
